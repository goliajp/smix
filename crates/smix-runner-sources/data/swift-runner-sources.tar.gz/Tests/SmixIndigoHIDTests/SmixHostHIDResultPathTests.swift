import XCTest
@testable import SmixIndigoHID

/// C4: `SmixHostHIDResult.success` must carry the `path` field set to whichever
/// dispatch implementation actually ran (`"digitizer"` vs `"indigo9"`).
/// The TS-side smoke script greps this value via `jq -e '.path == "digitizer"'`.
final class SmixHostHIDResultPathTests: XCTestCase {
  func test_success_pathDigitizer_jsonContainsPath() throws {
    let s = SmixHostHIDResult.success(
      path: "digitizer",
      resolved: [
        "IOHIDEventCreateDigitizerEvent",
        "IOHIDEventCreateDigitizerFingerEvent",
        "IOHIDEventAppendEvent",
        "IndigoHIDMessageForTrackpadEventFromHIDEventRef",
      ]
    )
    XCTAssertFalse(s.contains("\n"), "result must be single line: \(s)")
    let dict = try XCTUnwrap(
      try JSONSerialization.jsonObject(with: Data(s.utf8), options: []) as? [String: Any]
    )
    XCTAssertEqual(dict["ok"] as? Bool, true)
    XCTAssertEqual(dict["path"] as? String, "digitizer")
    let resolved = try XCTUnwrap(dict["resolved"] as? [String])
    XCTAssertTrue(
      resolved.contains("IndigoHIDMessageForTrackpadEventFromHIDEventRef"),
      "resolved must contain SimulatorKit trackpad wrap symbol: \(resolved)"
    )
    XCTAssertTrue(
      resolved.contains("IOHIDEventCreateDigitizerEvent"),
      "resolved must contain IOKit digitizer event symbol: \(resolved)"
    )
  }

  func test_success_pathIndigo9_unchanged() throws {
    // Behaviour identical to the `SmixHostHIDResultTests` lockdown — this
    // only asserts the path passthrough piece; the broader JSON shape is
    // that test's contract.
    let s = SmixHostHIDResult.success(
      path: "indigo9",
      resolved: ["IndigoHIDMessageForMouseNSEvent"]
    )
    let dict = try XCTUnwrap(
      try JSONSerialization.jsonObject(with: Data(s.utf8), options: []) as? [String: Any]
    )
    XCTAssertEqual(dict["ok"] as? Bool, true)
    XCTAssertEqual(dict["path"] as? String, "indigo9")
  }
}
