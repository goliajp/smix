import XCTest
import FlyingFox
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import SmixRunnerCore

final class TreeRouteTests: XCTestCase {

  // MARK: - helpers

  private func mkData(
    type: UInt = 9,
    identifier: String = "",
    label: String = "",
    value: String? = nil,
    frame: CGRect = CGRect(x: 0, y: 0, w: 100, h: 44),
    enabled: Bool = true,
    selected: Bool = false,
    hasFocus: Bool = false,
    children: [TreeRoute.A11ySnapshotData] = []
  ) -> TreeRoute.A11ySnapshotData {
    return TreeRoute.A11ySnapshotData(
      elementTypeRawValue: type,
      identifier: identifier,
      label: label,
      value: value,
      frame: frame,
      isEnabled: enabled,
      isSelected: selected,
      hasFocus: hasFocus,
      children: children
    )
  }

  private func parse(_ data: Data) -> [String: Any] {
    return (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any] ?? [:]
  }

  // MARK: - elementTypeName

  func test_elementTypeName_button_returnsButton() {
    XCTAssertEqual(TreeRoute.elementTypeName(9), "button")
  }

  func test_elementTypeName_cell_returnsCell() {
    XCTAssertEqual(TreeRoute.elementTypeName(75), "cell")
  }

  func test_elementTypeName_application_returnsApplication() {
    XCTAssertEqual(TreeRoute.elementTypeName(2), "application")
  }

  func test_elementTypeName_staticText_returnsStaticText() {
    XCTAssertEqual(TreeRoute.elementTypeName(48), "staticText")
  }

  func test_elementTypeName_unknown_returnsOther() {
    XCTAssertEqual(TreeRoute.elementTypeName(9999), "other")
    XCTAssertEqual(TreeRoute.elementTypeName(1), "other")
  }

  // MARK: - serialize

  func test_serialize_minimalLeaf_producesValidJSON() {
    let node = mkData(
      type: 9,
      label: "OK",
      frame: CGRect(x: 10, y: 20, w: 100, h: 44),
      enabled: true
    )
    let data = TreeRoute.serialize(node, logSink: nil)
    let obj = parse(data)
    XCTAssertEqual(obj["rawType"] as? String, "button")
    XCTAssertEqual(obj["label"] as? String, "OK")
    XCTAssertEqual(obj["enabled"] as? Bool, true)
    XCTAssertEqual(obj["selected"] as? Bool, false)
    XCTAssertEqual(obj["hasFocus"] as? Bool, false)
    XCTAssertEqual(obj["visible"] as? Bool, true)
    let bounds = obj["bounds"] as? [String: Any] ?? [:]
    XCTAssertEqual((bounds["x"] as? NSNumber)?.doubleValue, 10)
    XCTAssertEqual((bounds["y"] as? NSNumber)?.doubleValue, 20)
    XCTAssertEqual((bounds["w"] as? NSNumber)?.doubleValue, 100)
    XCTAssertEqual((bounds["h"] as? NSNumber)?.doubleValue, 44)
    XCTAssertNotNil(obj["children"] as? [Any])
  }

  func test_serialize_omitsEmptyIdentifierLabelValue() {
    let node = mkData(type: 9, identifier: "", label: "", value: nil)
    let data = TreeRoute.serialize(node, logSink: nil)
    let obj = parse(data)
    XCTAssertNil(obj["identifier"], "identifier key should be omitted when empty")
    XCTAssertNil(obj["label"], "label key should be omitted when empty")
    XCTAssertNil(obj["value"], "value key should be omitted when nil")
  }

  func test_serialize_nestedTwoLevels_childrenArrayPopulated() {
    let cell = mkData(
      type: 75,
      label: "General",
      frame: CGRect(x: 10, y: 100, w: 383, h: 44)
    )
    let app = mkData(
      type: 2,
      identifier: "com.apple.Preferences",
      frame: CGRect(x: 0, y: 0, w: 393, h: 852),
      children: [cell]
    )
    let data = TreeRoute.serialize(app, logSink: nil)
    let obj = parse(data)
    XCTAssertEqual(obj["rawType"] as? String, "application")
    XCTAssertEqual(obj["identifier"] as? String, "com.apple.Preferences")
    let kids = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(kids.count, 1)
    XCTAssertEqual(kids[0]["rawType"] as? String, "cell")
    XCTAssertEqual(kids[0]["label"] as? String, "General")
    let cb = kids[0]["bounds"] as? [String: Any] ?? [:]
    XCTAssertEqual((cb["x"] as? NSNumber)?.doubleValue, 10)
    XCTAssertEqual((cb["y"] as? NSNumber)?.doubleValue, 100)
  }

  // Visibility is a child-vs-root judgement now, so these pass a root with
  // a child rather than a lone node (a lone node is trivially visible
  // against itself). The "can say false" teeth are kept: a child outside
  // the root, and a zero-frame child, must still be false.
  func test_serialize_visibleHeuristic_childInsideRoot_true() {
    let child = mkData(frame: CGRect(x: 10, y: 100, w: 200, h: 44))
    let root = mkData(frame: CGRect(x: 0, y: 0, w: 393, h: 852), children: [child])
    let data = TreeRoute.serialize(root, logSink: nil)
    let kids = parse(data)["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(kids.first?["visible"] as? Bool, true)
  }

  func test_serialize_visibleHeuristic_childOutsideRoot_false() {
    let child = mkData(frame: CGRect(x: 900, y: 100, w: 10, h: 10))
    let root = mkData(frame: CGRect(x: 0, y: 0, w: 393, h: 852), children: [child])
    let data = TreeRoute.serialize(root, logSink: nil)
    let kids = parse(data)["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(kids.first?["visible"] as? Bool, false)
  }

  func test_serialize_visibleHeuristic_zeroFrameChild_false() {
    let child = mkData(frame: CGRect(x: 0, y: 0, w: 0, h: 0))
    let root = mkData(frame: CGRect(x: 0, y: 0, w: 393, h: 852), children: [child])
    let data = TreeRoute.serialize(root, logSink: nil)
    let kids = parse(data)["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(kids.first?["visible"] as? Bool, false)
  }

  // C6c: in landscape the app root is 874 wide; a node at x=407 is well
  // inside it. Visibility judged against a portrait appFrame (402 wide,
  // the stale value cached at portrait startup) wrongly calls it
  // off-screen. The judgement must be against the snapshot's own root.
  func test_serialize_visible_childBeyondPortraitWidthButInsideLandscapeRoot_true() {
    let child = mkData(identifier: "landscape-counter", frame: CGRect(x: 407, y: 73, w: 59, h: 114))
    let root = mkData(frame: CGRect(x: 0, y: 0, w: 874, h: 402), children: [child])
    let data = TreeRoute.serialize(root, logSink: nil)
    let obj = parse(data)
    let kids = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(kids.first?["visible"] as? Bool, true, "a node inside the landscape root is visible")
  }

  func test_serialize_truncatesAtMaxDepth() {
    // MAX_DEPTH is 500 because a real RN flat-deep dashboard genuinely nests
    // 80-200 levels; a limit of 60 truncated staticText nodes off the tree.
    // Build a chain deeper than MAX_DEPTH to verify the cliff still works.
    var chain = mkData(type: 9, label: "leaf")
    for _ in 0..<(TreeRoute.MAX_DEPTH + 2) {
      chain = mkData(type: 3, children: [chain])
    }
    var logs: [String] = []
    let logSink: (String) -> Void = { logs.append($0) }
    let data = TreeRoute.serialize(chain, logSink: logSink)
    // Walk down to MAX_DEPTH — at the cliff children must be an empty
    // array. Use [Any] cast (not [[String:Any]]) so we keep
    // walking while non-empty AND stop as soon as kids = [].
    var node: [String: Any] = parse(data)
    var depth = 0
    while let kids = node["children"] as? [Any], !kids.isEmpty {
      guard let next = kids.first as? [String: Any] else { break }
      node = next
      depth += 1
    }
    XCTAssertEqual(depth, TreeRoute.MAX_DEPTH, "walk should reach MAX_DEPTH=\(TreeRoute.MAX_DEPTH), actual=\(depth)")
    let kidsAtCliff = node["children"] as? [Any]
    XCTAssertEqual(kidsAtCliff?.count, 0, "expected empty children at MAX_DEPTH=\(TreeRoute.MAX_DEPTH), got \(kidsAtCliff as Any)")
    XCTAssertGreaterThanOrEqual(logs.count, 1)
    XCTAssertTrue(logs.contains { $0.contains("truncated") }, "logSink should record a 'truncated' warning, got \(logs)")
  }

  func test_serialize_hasFocusReflectsInput() {
    // `out["hasFocus"]` carries the POCO's real `hasFocus` value — on this
    // side it is a plain field passthrough. The UITest-side snapshotHandler
    // is what derives it: it finds the first responder by walking the
    // snapshot subtree depth-first, reading KVC
    // `value(forKey: "hasKeyboardFocus")`, then passes that node's
    // identifier down the convertSnapshotDict subtree as a focusHint and
    // sets hasFocus=true on the matching node.
    let inner = mkData(type: 9, label: "inner", hasFocus: false)
    let outer = mkData(type: 2, hasFocus: true, children: [inner])
    let data = TreeRoute.serialize(outer, logSink: nil)
    let obj = parse(data)
    XCTAssertEqual(obj["hasFocus"] as? Bool, true)
    let kids = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(kids.first?["hasFocus"] as? Bool, false)
  }

  func test_serialize_selectedFieldReflectsInput() {
    let node = mkData(type: 9, label: "Btn", selected: true)
    let data = TreeRoute.serialize(node, logSink: nil)
    let obj = parse(data)
    XCTAssertEqual(obj["selected"] as? Bool, true)
  }

  func test_serialize_valueFieldKept_whenNonEmpty() {
    let node = mkData(type: 49, label: "Email", value: "user@example.com")
    let data = TreeRoute.serialize(node, logSink: nil)
    let obj = parse(data)
    XCTAssertEqual(obj["value"] as? String, "user@example.com")
  }

  func test_serialize_fractionalBoundsPreserved() {
    let node = mkData(frame: CGRect(x: 10.0, y: 20.5, w: 300.0, h: 44.0))
    let data = TreeRoute.serialize(node, logSink: nil)
    let obj = parse(data)
    let bounds = obj["bounds"] as? [String: Any] ?? [:]
    XCTAssertEqual((bounds["y"] as? NSNumber)?.doubleValue, 20.5)
  }

  // MARK: - action-container button promotion

  // iOS 26.5 XCUITest exposes UIAlertController action buttons with
  // elementType `.other` (rawValue 1) instead of `.button` (9). Under
  // .alert / .dialog / .sheet ancestors we promote labeled `.other` /
  // `.staticText` nodes to `rawType: "button"` so `role: button` yaml
  // still matches on iOS 26+.

  func test_serialize_alertOtherChildWithLabel_promotedToButton() {
    let cancelBtn = mkData(type: 1, label: "Cancel")
    let okBtn = mkData(type: 1, label: "OK")
    let alert = mkData(type: 7, label: "Confirm", children: [cancelBtn, okBtn])
    let data = TreeRoute.serialize(alert, logSink: nil)
    let obj = parse(data)
    XCTAssertEqual(obj["rawType"] as? String, "alert")
    let children = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(children.count, 2)
    XCTAssertEqual(children[0]["rawType"] as? String, "button", "Cancel .other under .alert must promote to button")
    XCTAssertEqual(children[0]["label"] as? String, "Cancel")
    XCTAssertEqual(children[1]["rawType"] as? String, "button", "OK .other under .alert must promote to button")
  }

  func test_serialize_alertStaticTextChildWithLabel_promotedToButton() {
    let btn = mkData(type: 48, label: "Reload")
    let alert = mkData(type: 7, label: "Update", children: [btn])
    let data = TreeRoute.serialize(alert, logSink: nil)
    let obj = parse(data)
    let children = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(children[0]["rawType"] as? String, "button", ".staticText with label under .alert must promote")
  }

  func test_serialize_dialogNestedButton_promoted() {
    // .other button several layers deep under .dialog still promotes.
    let deepBtn = mkData(type: 1, label: "Retry")
    let inner = mkData(type: 3, children: [deepBtn])  // group wrapper
    let dialog = mkData(type: 8, label: "Error", children: [inner])
    let data = TreeRoute.serialize(dialog, logSink: nil)
    let obj = parse(data)
    let dialogChildren = obj["children"] as? [[String: Any]] ?? []
    let innerChildren = dialogChildren[0]["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(innerChildren[0]["rawType"] as? String, "button", "nested .other in dialog subtree must promote")
  }

  func test_serialize_alertOtherChildNoLabel_notPromoted() {
    // Empty-label .other under .alert stays as "other" — promotion
    // requires a non-empty label so we don't sweep up decorative
    // background views.
    let deco = mkData(type: 1, label: "")
    let alert = mkData(type: 7, label: "X", children: [deco])
    let data = TreeRoute.serialize(alert, logSink: nil)
    let obj = parse(data)
    let children = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(children[0]["rawType"] as? String, "other", "no-label .other under alert stays other")
  }

  func test_serialize_otherOutsideActionContainer_notPromoted() {
    // Baseline: .other with label OUTSIDE any alert/dialog/sheet must
    // remain `other` — promotion is scoped to action containers only.
    let leaf = mkData(type: 1, label: "just some other")
    let root = mkData(type: 2, children: [leaf])  // application
    let data = TreeRoute.serialize(root, logSink: nil)
    let obj = parse(data)
    let children = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(children[0]["rawType"] as? String, "other", ".other with label outside action container stays other")
  }

  func test_serialize_realButtonUnderAlert_stillButton() {
    // A real .button (rawValue 9) under .alert stays button. The
    // promotion only lifts `.other` / `.staticText` — never touches
    // pre-existing buttons.
    let btn = mkData(type: 9, label: "Yes")
    let alert = mkData(type: 7, label: "?", children: [btn])
    let data = TreeRoute.serialize(alert, logSink: nil)
    let obj = parse(data)
    let children = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(children[0]["rawType"] as? String, "button")
  }

  func test_serialize_sheetOtherChild_promoted() {
    // .sheet is an action container too — matches SwiftUI
    // .confirmationDialog / actionSheet exposure.
    let btn = mkData(type: 1, label: "Delete")
    let sheet = mkData(type: 5, label: "Delete confirm", children: [btn])
    let data = TreeRoute.serialize(sheet, logSink: nil)
    let obj = parse(data)
    let children = obj["children"] as? [[String: Any]] ?? []
    XCTAssertEqual(children[0]["rawType"] as? String, "button", ".other under .sheet must promote")
  }

  // MARK: - response builders

  func test_success_returns200WithBody() async throws {
    let payload = Data("[]".utf8)
    let resp = TreeRoute.success(payload)
    XCTAssertEqual(resp.statusCode, .ok)
    let body = try await String(decoding: resp.bodyData, as: UTF8.self)
    XCTAssertEqual(body, "[]")
    XCTAssertEqual(resp.headers[.contentType], "application/json")
  }

  func test_unavailable_returns500SnapshotUnavailable() async throws {
    let resp = TreeRoute.unavailable()
    XCTAssertEqual(resp.statusCode, .internalServerError)
    let bodyStr = try await String(decoding: resp.bodyData, as: UTF8.self)
    XCTAssertTrue(bodyStr.contains("\"ok\":false"), "body should contain ok:false, got \(bodyStr)")
    XCTAssertTrue(bodyStr.contains("\"error\":\"snapshot_unavailable\""), "body should contain error key, got \(bodyStr)")
    XCTAssertEqual(resp.headers[.contentType], "application/json")
  }

  // MARK: - isVisible direct

  func test_isVisible_intersectingFrame_true() {
    XCTAssertTrue(TreeRoute.isVisible(
      CGRect(x: 0, y: 800, w: 393, h: 100),
      CGRect(x: 0, y: 0, w: 393, h: 852)
    ))
  }
}

// Convenience init used only by tests to keep call sites short.
private extension CGRect {
  init(x: CGFloat, y: CGFloat, w: CGFloat, h: CGFloat) {
    self.init(x: x, y: y, width: w, height: h)
  }
}

final class TreeRouteLayerTests: XCTestCase {
  private func mkData(
    type: UInt, identifier: String = "", frame: CGRect,
    children: [TreeRoute.A11ySnapshotData] = []
  ) -> TreeRoute.A11ySnapshotData {
    TreeRoute.A11ySnapshotData(
      elementTypeRawValue: type, identifier: identifier, label: "", value: nil,
      frame: frame, isEnabled: true, isSelected: false, hasFocus: false, children: children)
  }

  // MARK: - a window's later layers cover its earlier ones

  private func node(_ d: [String: Any], id: String) -> [String: Any]? {
    if (d["identifier"] as? String) == id { return d }
    for c in (d["children"] as? [[String: Any]]) ?? [] {
      if let found = node(c, id: id) { return found }
    }
    return nil
  }

  /// The fixture's page sheet, as XCUITest snapshots it: the form, then a
  /// container the window draws after it holding the sheet.
  private func sheetOverForm(sheetFrame: CGRect) -> TreeRoute.A11ySnapshotData {
    let screen = CGRect(x: 0, y: 0, width: 402, height: 874)
    let formRow = mkData(type: 75, identifier: "form_row_3",
                         frame: CGRect(x: 16, y: 293.7, width: 370, height: 52))
    let sheetRow = mkData(type: 75, identifier: "sheet_row_3",
                          frame: CGRect(x: 16, y: 273.3, width: 370, height: 52))
    let form = mkData(type: 1, frame: screen, children: [formRow])
    let presentation = mkData(type: 1, frame: sheetFrame, children: [sheetRow])
    let window = mkData(type: 4, frame: screen, children: [form, presentation])
    return mkData(type: 2, frame: screen, children: [window])
  }

  func test_a_row_under_a_page_sheet_is_not_hittable() {
    var truncated = false
    let screen = CGRect(x: 0, y: 0, width: 402, height: 874)
    let d = TreeRoute.nodeToDictForTesting(
      sheetOverForm(sheetFrame: screen), rootFrame: screen, truncated: &truncated)
    XCTAssertEqual(node(d, id: "form_row_3")?["hittable"] as? Bool, false)
    XCTAssertNil(node(d, id: "sheet_row_3")?["hittable"],
                 "the layer on top is not covered by anything")
  }

  func test_a_layer_covers_only_where_it_is() {
    var truncated = false
    let screen = CGRect(x: 0, y: 0, width: 402, height: 874)
    // a banner across the bottom: the row near the top is not under it
    let d = TreeRoute.nodeToDictForTesting(
      sheetOverForm(sheetFrame: CGRect(x: 0, y: 780, width: 402, height: 94)),
      rootFrame: screen, truncated: &truncated)
    XCTAssertNil(node(d, id: "form_row_3")?["hittable"])
  }

  func test_a_window_with_one_child_covers_nothing() {
    var truncated = false
    let screen = CGRect(x: 0, y: 0, width: 402, height: 874)
    let row = mkData(type: 75, identifier: "row", frame: CGRect(x: 16, y: 300, width: 370, height: 52))
    let window = mkData(type: 4, frame: screen, children: [mkData(type: 1, frame: screen, children: [row])])
    let d = TreeRoute.nodeToDictForTesting(
      mkData(type: 2, frame: screen, children: [window]), rootFrame: screen, truncated: &truncated)
    XCTAssertNil(node(d, id: "row")?["hittable"])
  }
}
