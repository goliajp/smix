import FlyingFox
import Foundation

// POST /hide-keyboard {} → 200 {ok:<bool>}.
// Mirrors BackRoute / ForegroundRoute envelope shape. The runner-side
// handler tries the keyboard's own keys, a drag of the focused field's
// scroll view into the keyboard (KeyboardDismissDrag), and touches outside
// it, checking after each whether the keyboard is gone. The route owns
// request decoding + response serialization only.
//
// Empty body or `{}` JSON object both decode to HideKeyboardRequest. Hide-
// keyboard is bound-app frontmost-keyboard scope — no bundleId / no selector
// (mirrors /back which is also parameterless).
public enum HideKeyboardRoute {
  public struct HideKeyboardRequest: Equatable, Sendable {
    /// How long the host will wait, in milliseconds. The handler stops
    /// starting strategies once it is spent, so its answer arrives while
    /// the host is still listening. Absent from older hosts: no bound.
    public var budgetMs: Int?
    public init(budgetMs: Int? = nil) { self.budgetMs = budgetMs }
  }

  public enum DecodeError: Error, Equatable {
    case invalidJSON
  }

  public static func decode(_ body: Data) throws -> HideKeyboardRequest {
    // Empty body acceptable — hide-keyboard is parameterless.
    if body.isEmpty { return HideKeyboardRequest() }
    let json: Any
    do { json = try JSONSerialization.jsonObject(with: body, options: []) }
    catch { throw DecodeError.invalidJSON }
    // Any valid JSON object body (including `{}`) is acceptable; ignore any
    // unexpected fields — hide-keyboard's contract is parameterless and
    // additive payload fields are forward-compatible.
    guard let object = json as? [String: Any] else { throw DecodeError.invalidJSON }
    let budget = (object["budgetMs"] as? NSNumber).map { $0.intValue }
    return HideKeyboardRequest(budgetMs: budget.flatMap { $0 > 0 ? $0 : nil })
  }

  /// What actually happened, so the answer can say which.
  ///
  /// `ok:false` used to mean three things at once — the strategies ran and
  /// the keyboard stayed, XCUITest raised inside the guarded block, and the
  /// request context was lost — and a caller cannot act on the union. A
  /// consumer met it with the keyboard unmistakably on screen and could not
  /// tell it from the answer for no keyboard at all.
  ///
  /// The two successes stay one answer on the wire: whether the keyboard was
  /// already gone or was just dismissed, the caller's next step is the same.
  public enum Outcome: Equatable, Sendable {
    /// There was no keyboard. The intent is already satisfied.
    case alreadyGone
    /// A keyboard is in the tree and none of it is on screen — a simulator
    /// that minimizes its keyboard keeps one below the display while a
    /// field holds focus. Nothing is covered, so the intent is satisfied;
    /// the answer says so, and which field still has focus, because the
    /// keys of that keyboard cannot be pressed and focus did not move.
    case offScreen(focus: String, seen: String)
    /// There was one, and it is gone now.
    case dismissed
    /// There was one, every strategy ran, and it is still there.
    case stillPresent(tried: String)
    /// Something went wrong while looking. NOT evidence the keyboard is up.
    case couldNotTell(why: String)
  }

  public static func outcome(_ o: Outcome) -> HTTPResponse {
    switch o {
    case .alreadyGone, .dismissed:
      return success(ok: true)
    case .offScreen(let focus, let seen):
      let f = jsonEscape(focus)
      let w = jsonEscape(seen)
      return envelope(.ok, Data(
        #"{"ok":true,"saw":"the keyboard is below the screen (minimized) and covers nothing — \#(w); focus stays on \#(f)"}"#.utf8))
    case .stillPresent(let tried):
      let t = jsonEscape(tried)
      return envelope(.ok, Data(
        #"{"ok":false,"error":"keyboard_did_not_close","saw":"\#(t)"}"#.utf8))
    case .couldNotTell(let why):
      let w = jsonEscape(why)
      return envelope(.ok, Data(
        #"{"ok":false,"error":"keyboard_state_unknown","saw":"\#(w)"}"#.utf8))
    }
  }

  /// Whether any of the keyboard's frame is inside the app's. A keyboard
  /// the tree reports and the display does not show is not one to dismiss:
  /// its keys cannot be tapped and it hides nothing. Measured on a
  /// consumer's iOS 27 simulator: keyboard at y=918 on an 874-point screen,
  /// `exists` true, every strategy run against it and failing.
  public static func keyboardOnScreen(keyboard: CGRect, app: CGRect) -> Bool {
    let shown = keyboard.intersection(app)
    return !shown.isNull && shown.width > 0 && shown.height > 0
  }

  /// One look at the keyboard while deciding whether an off-screen one
  /// is minimized or still on its way in.
  public enum KeyboardSighting: Equatable, Sendable {
    case gone
    case onScreen
    case offScreen(CGRect)
  }

  public enum OffScreenVerdict: Equatable, Sendable {
    /// It left while we looked: nothing to dismiss.
    case gone
    /// It came onto the screen: dismiss it as usual.
    case onScreen
    /// It stayed in one place below the screen for `hold`: minimized.
    case minimized(CGRect)
  }

  /// What a run of looks at a keyboard first seen off the screen says, or
  /// nil to keep looking.
  ///
  /// One look could not tell a minimized keyboard from one still sliding
  /// in: right after typing, the keyboard's frame had not reached the
  /// screen yet, `hideKeyboard` answered "minimized" without trying
  /// anything, and the keyboard finished arriving and stayed up — three
  /// runs of three in a consumer's flows. Minimized is a place it stays,
  /// so it takes the same frame across `hold`.
  public static func offScreenVerdict(
    _ looks: [(at: TimeInterval, sighting: KeyboardSighting)], hold: TimeInterval
  ) -> OffScreenVerdict? {
    guard let last = looks.last else { return nil }
    switch last.sighting {
    case .gone: return .gone
    case .onScreen: return .onScreen
    case .offScreen(let frame):
      var since = last.at
      for look in looks.reversed() {
        guard case .offScreen(let f) = look.sighting, f == frame else { break }
        since = look.at
      }
      return last.at - since >= hold ? .minimized(frame) : nil
    }
  }

  public static func success(ok: Bool) -> HTTPResponse {
    let body = Data(#"{"ok":\#(ok)}"#.utf8)
    return envelope(.ok, body)
  }

  public static func badRequest(reason: String) -> HTTPResponse {
    let r = jsonEscape(reason)
    let body = Data(#"{"ok":false,"error":"bad_request","reason":"\#(r)"}"#.utf8)
    return envelope(.badRequest, body)
  }

  private static func envelope(_ status: HTTPStatusCode, _ body: Data) -> HTTPResponse {
    HTTPResponse(
      statusCode: status,
      headers: [.contentType: "application/json"],
      body: body
    )
  }

  private static func jsonEscape(_ s: String) -> String {
    // Same minimal-escape policy as BackRoute / ForegroundRoute (control +
    // quote + backslash). Local copy keeps route modules self-contained.
    var out = ""
    out.reserveCapacity(s.count)
    for ch in s {
      switch ch {
      case "\"": out += "\\\""
      case "\\": out += "\\\\"
      case "\n": out += "\\n"
      case "\r": out += "\\r"
      case "\t": out += "\\t"
      default:
        if let scalar = ch.unicodeScalars.first, scalar.value < 0x20 {
          out += String(format: "\\u%04x", scalar.value)
        } else {
          out.append(ch)
        }
      }
    }
    return out
  }
}
