import FlyingFox
import Foundation

// POST /find-text-by-ocr {"text":"...","locales":["en"]}
//   → 200 {"found": bool, "frame": [nx, ny, w, h]?}
//
// Sense layer for a11y-less and internationalized screens. Apple Vision OCR
// over the current XCUIScreen.main screenshot. Returns the first matching
// text observation's bounding box normalized to [0,1] in UIKit coord space
// (top-left origin, y-down — Vision's native [0,1] is bottom-left, y-up;
// handler converts).
//
// Locales default to ["en"] when empty/missing. Pass BCP-47 language
// subtags (e.g. "en", "ja", "es"). Apple Vision uses these to pick the
// recognition language model — accuracy lifts ~15-30% when correct
// locale is provided per Apple docs.
//
// Wire shape:
//   request:  {"text": "Submit", "locales": ["en"], "recognition_level": "accurate"}
//             locales / recognition_level optional, defaults shown.
//   response: 200 {"found": true,  "frame": [0.32, 0.85, 0.12, 0.04]}
//             200 {"found": false, "frame": null}
//             400 {"found": false, "error": "bad_request", "reason": "..."}
public enum FindTextByOcrRoute {
  public struct FindTextByOcrRequest: Equatable, Sendable {
    public let text: String
    public let locales: [String]
    /// "accurate" (default, slower + higher accuracy) or "fast".
    public let recognitionLevel: String
    public init(text: String, locales: [String], recognitionLevel: String) {
      self.text = text
      self.locales = locales
      self.recognitionLevel = recognitionLevel
    }
  }

  public enum DecodeError: Error, Equatable {
    case invalidJSON
    case missingText
    case invalidField(String, String)
  }

  public static func decode(_ body: Data) throws -> FindTextByOcrRequest {
    let json: Any
    do { json = try JSONSerialization.jsonObject(with: body, options: []) }
    catch { throw DecodeError.invalidJSON }
    guard let root = json as? [String: Any] else { throw DecodeError.invalidJSON }

    guard let raw = root["text"] else { throw DecodeError.missingText }
    guard let s = raw as? String else {
      throw DecodeError.invalidField("text", "\(raw)")
    }
    guard !s.isEmpty else {
      throw DecodeError.invalidField("text", "empty")
    }

    var locales: [String] = ["en"]
    if let l = root["locales"] {
      guard let arr = l as? [String] else {
        throw DecodeError.invalidField("locales", "\(l)")
      }
      if !arr.isEmpty { locales = arr }
    }

    var level = "accurate"
    if let r = root["recognition_level"] {
      guard let lvl = r as? String else {
        throw DecodeError.invalidField("recognition_level", "\(r)")
      }
      guard lvl == "accurate" || lvl == "fast" else {
        throw DecodeError.invalidField("recognition_level", lvl)
      }
      level = lvl
    }

    return FindTextByOcrRequest(text: s, locales: locales, recognitionLevel: level)
  }

  /// Which recognized string the needle meant, out of everything on
  /// screen.
  ///
  /// Pure, so the rule can be tested without a screen. It used to live
  /// inside the Vision callback and read "the first observation whose
  /// text contains the needle, in whatever order the recognizer
  /// returned them". On iOS's notification alert that is `Don't Allow`
  /// and `Allow`, so an ocrText of "Allow" tapped Don't Allow and
  /// reported success — and iOS never asks a second time, so the app
  /// had to be reinstalled to try again.
  ///
  /// An exact reading wins outright: "Allow" beside "Don't Allow" is not
  /// ambiguous to a person and must not be here. With no exact reading,
  /// a single substring match is taken; two or more is `nil`, because
  /// choosing between them is a coin flip the caller never sees.
  public static func pick(needle: String, from candidates: [String]) -> Int? {
    let want = needle.lowercased().trimmingCharacters(in: .whitespaces)
    var exact: [Int] = []
    var partial: [Int] = []
    for (i, c) in candidates.enumerated() {
      let seen = c.lowercased().trimmingCharacters(in: .whitespaces)
      if seen == want {
        exact.append(i)
      } else if seen.contains(want) {
        partial.append(i)
      }
    }
    let chosen = exact.isEmpty ? partial : exact
    return chosen.count == 1 ? chosen.first : nil
  }

  public static func success(found: Bool, frame: (Double, Double, Double, Double)?)
    -> HTTPResponse
  {
    let body: Data
    if let f = frame {
      let s = #"{"found":\#(found),"frame":[\#(f.0),\#(f.1),\#(f.2),\#(f.3)]}"#
      body = Data(s.utf8)
    } else {
      body = Data(#"{"found":\#(found),"frame":null}"#.utf8)
    }
    return envelope(.ok, body)
  }

  /// Why this platform reads no text from pixels, or nil where it does.
  /// "Not found" would be a different answer: it says the words are not
  /// on the screen, when here nothing was looked for.
  public static var unavailableHere: String? {
    #if os(watchOS)
      return "watchOS has no text recognition (Vision's text requests are not on a watch); "
        + "name the element by id, text or label instead"
    #else
      return nil
    #endif
  }

  /// The refusal for a platform with no text recognition: `ok:false`, the
  /// name, and the reason in `saw` where the host reads it.
  public static func unavailable(_ saw: String) -> HTTPResponse {
    let body = try! JSONSerialization.data(
      withJSONObject: ["found": false, "ok": false, "error": "unsupported_on_platform", "saw": saw],
      options: [.sortedKeys])
    return HTTPResponse(statusCode: .ok, headers: [.contentType: "application/json"], body: body)
  }

  public static func badRequest(reason: String) -> HTTPResponse {
    let escaped = reason.replacingOccurrences(of: "\\", with: "\\\\")
      .replacingOccurrences(of: "\"", with: "\\\"")
    let body = Data(#"{"found":false,"error":"bad_request","reason":"\#(escaped)"}"#.utf8)
    return envelope(.badRequest, body)
  }

  private static func envelope(_ status: HTTPStatusCode, _ body: Data) -> HTTPResponse {
    HTTPResponse(
      statusCode: status,
      headers: [.contentType: "application/json"],
      body: body
    )
  }
}
