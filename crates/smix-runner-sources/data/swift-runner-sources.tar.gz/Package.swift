// swift-tools-version: 5.9
import PackageDescription

let package = Package(
  name: "SmixRunnerCore",
  platforms: [.iOS(.v17), .macOS(.v13), .visionOS(.v1)],
  products: [
    .library(name: "SmixRunnerCore", targets: ["SmixRunnerCore"]),
  ],
  dependencies: [
    .package(url: "https://github.com/swhitty/FlyingFox.git", .upToNextMajor(from: "0.27.1")),
  ],
  targets: [
    .target(
      name: "SmixRunnerCore",
      dependencies: [.product(name: "FlyingFox", package: "FlyingFox")]
    ),

  ]
)
