// Calls into the private ObjC classes XCSynthesizedEventRecord,
// XCPointerEventPath and XCTRunnerDaemonSession to synthesize a raw
// IOKit-level touch event (one with no XCUIElement-owner metadata). The
// event goes through UIKit's standard `UIApplication.sendEvent:` hit-test,
// which is what makes a React Native Pressable actually fire onPress.
//
// The approach mirrors maestro `cli-2.2.0`:
//   - maestro-driver-iosUITests/Routes/Handlers/TouchRouteHandler.swift
//   - maestro-driver-iosUITests/Routes/XCTest/EventRecord.swift
//   - maestro-driver-iosUITests/Routes/XCTest/PointerEventPath.swift
//   - maestro-driver-iosUITests/Routes/XCTest/RunnerDaemonProxy.swift
// Those four are merged into this single file because the swift-bridge
// target is flat.
//
// Private-symbol policy: private symbols must be reached dynamically and
// never hard-linked. Everything here goes through `NSClassFromString` /
// `objc_lookUpClass` plus `unsafeBitCast(method(for:), to: ...)`, the same
// pattern as the existing `DaemonKeyboard.sendString`.

import Foundation
import SmixRunnerCore
import ObjectiveC
import UIKit
import XCTest

/// alloc helper. Swift does not allow calling `AnyClass.alloc()` directly
/// (deprecated since Swift 5.x), so fetch the `alloc` IMP through the ObjC
/// runtime with class_getClassMethod + method_getImplementation and call it
/// via unsafeBitCast.
private func ocAlloc(_ className: String) -> NSObject? {
  guard let cls = NSClassFromString(className) else { return nil }
  let sel = NSSelectorFromString("alloc")
  guard let m = class_getClassMethod(cls, sel) else { return nil }
  let imp = method_getImplementation(m)
  typealias AllocFn = @convention(c) (AnyClass, Selector) -> NSObject
  let fn = unsafeBitCast(imp, to: AllocFn.self)
  return fn(cls, sel)
}

/// Wraps `XCPointerEventPath` private ObjC class. Constructed via
/// `initForTouchAtPoint:offset:`; lifted via `liftUpAtOffset:`; intermediate
/// `moveToPoint:atOffset:` calls compose swipe / drag gestures.
final class SmixPointerEventPath {
  let path: NSObject
  var offset: TimeInterval

  static func forTouch(at point: CGPoint, offset: TimeInterval = 0) -> SmixPointerEventPath? {
    guard let alloced = ocAlloc("XCPointerEventPath") else { return nil }
    let selector = NSSelectorFromString("initForTouchAtPoint:offset:")
    let imp = alloced.method(for: selector)
    typealias InitFn = @convention(c) (NSObject, Selector, CGPoint, TimeInterval) -> NSObject
    let initFn = unsafeBitCast(imp, to: InitFn.self)
    let path = initFn(alloced, selector, point, offset)
    return SmixPointerEventPath(path: path, offset: offset)
  }

  /// Swipe path: touch-down at `from`, drag to `to` over `duration`,
  /// then `liftUp` at the same offset. The caller adds the path to a
  /// SmixEventRecord and dispatches via daemonProxy.
  static func forSwipe(
    from start: CGPoint, to end: CGPoint, duration: TimeInterval = 0.3
  ) -> SmixPointerEventPath? {
    guard let p = forTouch(at: start, offset: 0) else { return nil }
    p.moveTo(point: end, atOffset: duration)
    p.offset = duration
    return p
  }

  private init(path: NSObject, offset: TimeInterval) {
    self.path = path
    self.offset = offset
  }

  /// Add an intermediate path point at `offset`; used to compose
  /// swipe / drag gestures between `forTouch` (touch-down) and `liftUp`.
  func moveTo(point: CGPoint, atOffset offset: TimeInterval) {
    let selector = NSSelectorFromString("moveToPoint:atOffset:")
    let imp = path.method(for: selector)
    typealias Method = @convention(c) (NSObject, Selector, CGPoint, TimeInterval) -> Void
    let method = unsafeBitCast(imp, to: Method.self)
    method(path, selector, point, offset)
  }

  func liftUp() {
    let selector = NSSelectorFromString("liftUpAtOffset:")
    let imp = path.method(for: selector)
    typealias Method = @convention(c) (NSObject, Selector, TimeInterval) -> Void
    let method = unsafeBitCast(imp, to: Method.self)
    method(path, selector, offset)
  }
}

/// Wraps `XCSynthesizedEventRecord` private ObjC class. Records one or more
/// `XCPointerEventPath` instances + dispatches them via daemonProxy.
final class SmixEventRecord {
  let record: NSObject
  static let defaultTapDuration: TimeInterval = 0.1

  /// `displayID` is the screen the app is on. Without it the record goes
  /// to the main screen, which on a foldable unfolded is the dark outer
  /// panel: every touch was reported as delivered and none arrived.
  init?(orientation: UIInterfaceOrientation, displayID: UInt64?) {
    guard let alloced = ocAlloc("XCSynthesizedEventRecord") else { return nil }
    let name = "Single-Finger Touch Action" as NSString
    let onDisplay = NSSelectorFromString("initWithName:displayID:interfaceOrientation:")
    if let displayID, alloced.responds(to: onDisplay) {
      typealias InitFn = @convention(c) (
        NSObject, Selector, NSString, UInt64, UIInterfaceOrientation
      ) -> NSObject
      let initFn = unsafeBitCast(alloced.method(for: onDisplay), to: InitFn.self)
      self.record = initFn(alloced, onDisplay, name, displayID, orientation)
      return
    }
    let selector = NSSelectorFromString("initWithName:interfaceOrientation:")
    let imp = alloced.method(for: selector)
    typealias InitFn = @convention(c) (
      NSObject, Selector, NSString, UIInterfaceOrientation
    ) -> NSObject
    let initFn = unsafeBitCast(imp, to: InitFn.self)
    self.record = initFn(alloced, selector, name, orientation)
  }

  /// Build a tap event path at `point` (touch-down + liftUp after
  /// `defaultTapDuration`) and add to this record.
  func addPointerTouchEvent(at point: CGPoint) -> Bool {
    guard let path = SmixPointerEventPath.forTouch(at: point) else { return false }
    path.offset = SmixEventRecord.defaultTapDuration
    path.liftUp()
    let selector = NSSelectorFromString("addPointerEventPath:")
    let imp = record.method(for: selector)
    typealias Method = @convention(c) (NSObject, Selector, NSObject) -> Void
    let method = unsafeBitCast(imp, to: Method.self)
    method(record, selector, path.path)
    return true
  }

  /// Add one touch at `point`, held for `holdMs`.
  ///
  /// A burst is a record per touch, synthesised in turn: paths sharing a
  /// record are separate fingers, and their start offsets are not kept.
  func addPointerTap(at point: CGPoint, holdMs: Int) -> Bool {
    guard let path = SmixPointerEventPath.forTouch(at: point, offset: 0) else {
      return false
    }
    path.offset = TouchTimeline.upOffset(downOffset: 0, holdMs: holdMs)
    path.liftUp()
    let selector = NSSelectorFromString("addPointerEventPath:")
    let imp = record.method(for: selector)
    typealias Method = @convention(c) (NSObject, Selector, NSObject) -> Void
    let method = unsafeBitCast(imp, to: Method.self)
    method(record, selector, path.path)
    return true
  }

  /// Add a double tap at `point`: two touches in this one record.
  ///
  /// Two paths in one record are delivered close together whatever
  /// their offsets say, which a double-tap recogniser accepts and a
  /// counter of separate presses does not.
  func addPointerDoubleTap(at point: CGPoint, intervalMs: Int, holdMs: Int) -> Bool {
    let selector = NSSelectorFromString("addPointerEventPath:")
    for down in TouchTimeline.downOffsets(times: 2, intervalMs: intervalMs) {
      guard let path = SmixPointerEventPath.forTouch(at: point, offset: down) else {
        return false
      }
      path.offset = TouchTimeline.upOffset(downOffset: down, holdMs: holdMs)
      path.liftUp()
      let imp = record.method(for: selector)
      typealias Method = @convention(c) (NSObject, Selector, NSObject) -> Void
      let method = unsafeBitCast(imp, to: Method.self)
      method(record, selector, path.path)
    }
    return true
  }

  /// Build a swipe event path: touch-down at `from`, drag to `to`
  /// over `duration`, then liftUp. Returns false if `XCPointerEventPath`
  /// allocation failed (Apple bumped the private API on this OS).
  /// Default duration mirrors maestro `cli-2.2.0` swipe handler (0.3s).
  static let defaultSwipeDuration: TimeInterval = 0.3
  func addPointerSwipeEvent(
    from start: CGPoint, to end: CGPoint, duration: TimeInterval = 0.3
  ) -> Bool {
    guard let path = SmixPointerEventPath.forSwipe(
      from: start, to: end, duration: duration)
    else { return false }
    path.liftUp()
    let selector = NSSelectorFromString("addPointerEventPath:")
    let imp = record.method(for: selector)
    typealias Method = @convention(c) (NSObject, Selector, NSObject) -> Void
    let method = unsafeBitCast(imp, to: Method.self)
    method(record, selector, path.path)
    return true
  }
}

extension SmixEventRecord {
  /// Add two fingers that move from `start` to `pinched` over
  /// `durationMs`, then, when `panMs > 0`, on to `end` without lifting.
  ///
  /// Each finger comes down where `plan.down` says and moves to the start
  /// over `PinchRoute.prerollMs` — the run-up the request asked for — so
  /// the app's recognizer has begun by the time the counted pinch does.
  ///
  /// Both paths go in this one record, which is what makes them two
  /// fingers on the screen at once rather than two touches in turn.
  func addPointerPinch(
    _ plan: PinchRoute.PinchPlan, durationMs: Int, panMs: Int
  ) -> Bool {
    let preroll = plan.down == plan.start ? 0 : TimeInterval(PinchRoute.prerollMs) / 1000
    let pinchAt = preroll + TimeInterval(durationMs) / 1000
    let panAt = pinchAt + TimeInterval(panMs) / 1000
    let liftAt = panAt + TimeInterval(PinchRoute.holdBeforeLiftMs) / 1000
    let selector = NSSelectorFromString("addPointerEventPath:")
    let fingers = [
      (plan.down.first, plan.start.first, plan.pinched.first, plan.end.first),
      (plan.down.second, plan.start.second, plan.pinched.second, plan.end.second),
    ]
    for (back, from, mid, to) in fingers {
      guard let path = SmixPointerEventPath.forTouch(at: back, offset: 0) else { return false }
      if preroll > 0 { path.moveTo(point: from, atOffset: preroll) }
      path.moveTo(point: mid, atOffset: pinchAt)
      if panMs > 0 { path.moveTo(point: to, atOffset: panAt) }
      path.offset = liftAt
      path.liftUp()
      let imp = record.method(for: selector)
      typealias Method = @convention(c) (NSObject, Selector, NSObject) -> Void
      let method = unsafeBitCast(imp, to: Method.self)
      method(record, selector, path.path)
    }
    return true
  }
}

/// Wraps `XCTRunnerDaemonSession.sharedSession.daemonProxy` for raw event
/// synthesis. Same proxy as `DaemonKeyboard` (which uses `_XCT_sendString:...`);
/// this class uses `_XCT_synthesizeEvent:completion:`.
final class SmixRunnerDaemonProxy: @unchecked Sendable {
  static let shared = SmixRunnerDaemonProxy()
  private let proxy: NSObject?

  private init() {
    guard let clazz = NSClassFromString("XCTRunnerDaemonSession") else {
      self.proxy = nil; return
    }
    let sharedSel = NSSelectorFromString("sharedSession")
    let imp = clazz.method(for: sharedSel)
    typealias SharedFn = @convention(c) (AnyClass, Selector) -> NSObject
    let session = unsafeBitCast(imp, to: SharedFn.self)(clazz, sharedSel)
    self.proxy = session.perform(NSSelectorFromString("daemonProxy"))?
      .takeUnretainedValue() as? NSObject
  }

  /// Dispatch a synthesized event record via daemonProxy. Awaits the
  /// completion callback. Throws on missing proxy / daemon error.
  func synthesize(record: SmixEventRecord) async throws {
    guard let proxy = self.proxy else {
      throw NSError(
        domain: "SmixRunnerDaemonProxy", code: 1,
        userInfo: [NSLocalizedDescriptionKey:
          "XCTRunnerDaemonSession daemonProxy unavailable"])
    }
    let selector = NSSelectorFromString("_XCT_synthesizeEvent:completion:")
    let imp = proxy.method(for: selector)
    typealias Method = @convention(c) (
      NSObject, Selector, NSObject, @escaping (Error?) -> Void
    ) -> Void
    let method = unsafeBitCast(imp, to: Method.self)
    return try await withCheckedThrowingContinuation { continuation in
      method(proxy, selector, record.record) { error in
        if let error = error {
          continuation.resume(throwing: error)
        } else {
          continuation.resume(returning: ())
        }
      }
    }
  }
}

/// The interface orientation every synthesised event is stamped with.
///
/// It was written out at six call sites as a literal `.portrait`. That
/// is the value `XCSynthesizedEventRecord` uses to decide how the
/// points in an event path are read, so a landscape app receives
/// touches computed in its own frame and interpreted as though the
/// screen were portrait — which is the defect under investigation in
/// v5.1. Naming it once does not change it; it makes
/// `GET /coordinate-space` able to report the same value the touches
/// actually carry, instead of a comment claiming what they carry.
let smixEventRecordOrientation: UIInterfaceOrientation = .portrait

func describeInterfaceOrientation(_ o: UIInterfaceOrientation) -> String {
  switch o {
  case .portrait: return "portrait"
  case .portraitUpsideDown: return "portraitUpsideDown"
  case .landscapeLeft: return "landscapeLeft"
  case .landscapeRight: return "landscapeRight"
  case .unknown: return "unknown"
  @unknown default: return "unknown"
  }
}

func describeDeviceOrientation(_ o: UIDeviceOrientation) -> String {
  switch o {
  case .portrait: return "portrait"
  case .portraitUpsideDown: return "portraitUpsideDown"
  // Named as the interface would name them, so the two strings this
  // route returns are comparable at all. UIDeviceOrientation's
  // landscapeLeft is the interface's landscapeRight — comparing the
  // raw names would report a mismatch that is only a vocabulary
  // difference, and hide a real one behind it.
  case .landscapeLeft: return "landscapeRight"
  case .landscapeRight: return "landscapeLeft"
  case .faceUp: return "faceUp"
  case .faceDown: return "faceDown"
  case .unknown: return "unknown"
  @unknown default: return "unknown"
  }
}

/// Which repair is in force, read once.
///
/// Two are possible and only a device can say which the system honours,
/// so both are buildable and the default is what already shipped: the
/// experiment must not itself be a change in behaviour.
let smixEventStampStrategy = EventStampStrategy.fromEnvironment()

func smixUIOrientation(_ o: StampOrientation) -> UIInterfaceOrientation {
  switch o {
  case .portrait: return .portrait
  case .portraitUpsideDown: return .portraitUpsideDown
  case .landscapeLeft: return .landscapeLeft
  case .landscapeRight: return .landscapeRight
  }
}

/// The app's size and which way it is turned, read together.
///
/// The frame says the app is wide, not whether it was turned left or
/// right; converting a point from the frame alone put every touch in one
/// of the two landscapes in the opposite corner of the screen.
struct SmixLayout {
  let size: CGSize
  let orientation: StampOrientation
  /// Where the orientation came from: "app", "device" or "frame".
  let source: String
  /// The screen the app is on when it is not the main one; nil means main.
  let displayID: UInt64?
}

func smixStamp(_ o: UIInterfaceOrientation) -> StampOrientation? {
  switch o {
  case .portrait: return .portrait
  case .portraitUpsideDown: return .portraitUpsideDown
  case .landscapeLeft: return .landscapeLeft
  case .landscapeRight: return .landscapeRight
  default: return nil
  }
}

/// Read where `app.frame` is read — XCUIApplication is main-thread only.
///
/// The app's own interface orientation comes from a private XCTest
/// property, looked up by name so a release that drops it falls back to
/// the device rather than failing to load.
func smixLayout(of app: XCUIApplication) -> SmixLayout {
  let size = app.frame.size
  var reported: StampOrientation?
  if app.responds(to: NSSelectorFromString("interfaceOrientation")),
    let raw = app.value(forKey: "interfaceOrientation") as? Int,
    let o = UIInterfaceOrientation(rawValue: raw)
  {
    reported = smixStamp(o)
  }
  let device: StampOrientation?
  switch XCUIDevice.shared.orientation {
  case .portrait: device = .portrait
  case .portraitUpsideDown: device = .portraitUpsideDown
  // The device turned left shows the interface turned right.
  case .landscapeLeft: device = .landscapeRight
  case .landscapeRight: device = .landscapeLeft
  default: device = nil
  }
  let orientation = layoutOrientation(appFrame: size, reported: reported, device: device)
  let source =
    reported != nil ? "app" : (size.width > size.height && device != nil && device != .portrait && device != .portraitUpsideDown ? "device" : "frame")
  let displayID = smixDisplayID(showing: size)
  return SmixLayout(size: size, orientation: orientation, source: source, displayID: displayID)
}

/// The screen an app of this size fills, when it is not the main one.
///
/// XCTest resolves every app to the main screen (`displayID` reads 0 and
/// `_resolvedDisplayIDForSnapshot:` falls back to the main id), and on a
/// foldable unfolded the main screen is the dark outer panel. The panels
/// differ in size, so the one whose size in points matches the app's frame, either
/// way round, is the one the app is on. Nil keeps the main screen: for a
/// one-screen device, and whenever the match is not exactly one panel.
func smixDisplayID(showing size: CGSize) -> UInt64? {
  let screens = XCUIScreen.screens
  guard screens.count > 1 else { return nil }
  let fits = screens.filter { screen in
    // bounds are in pixels, the app's frame in points
    guard let px = (screen.value(forKey: "bounds") as? NSValue)?.cgRectValue.size,
      let scale = (screen.value(forKey: "scale") as? NSNumber).map({ CGFloat($0.doubleValue) }),
      scale > 0
    else { return false }
    let pt = CGSize(width: px.width / scale, height: px.height / scale)
    return pt == size || pt == CGSize(width: size.height, height: size.width)
  }
  guard fits.count == 1, fits[0] != XCUIScreen.main else { return nil }
  return (fits[0].value(forKey: "displayID") as? NSNumber)?.uint64Value
}

/// The screen the app is drawn on. `XCUIScreen.main` is the main panel
/// whether or not anything is lit on it, which on a foldable unfolded is
/// the dark outer one.
func smixScreen(showing app: XCUIApplication) -> XCUIScreen {
  guard let id = smixLayout(of: app).displayID else { return XCUIScreen.main }
  return XCUIScreen.screens.first {
    ($0.value(forKey: "displayID") as? NSNumber)?.uint64Value == id
  } ?? XCUIScreen.main
}

/// The stamp and the point to deliver, for a point in the app's space.
///
/// Every synthesised touch in this file goes through here, so a strategy
/// cannot be in force for taps and not for swipes — which is the shape
/// of a fix that passes its own test and leaves half the surface broken.
func smixDelivery(
  of point: CGPoint, layout: SmixLayout
) -> (orientation: UIInterfaceOrientation, point: CGPoint, displayID: UInt64?) {
  let stamp = eventStamp(forAppFrame: layout.size, strategy: smixEventStampStrategy)
  guard smixEventStampStrategy == .convertPointToDeviceSpace else {
    return (smixUIOrientation(stamp), point, layout.displayID)
  }
  return (
    smixUIOrientation(stamp),
    pointInDeviceSpace(point, appFrame: layout.size, interface: layout.orientation),
    layout.displayID
  )
}
