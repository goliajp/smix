package dev.smix.probe

import android.os.Handler
import android.view.View
import android.view.WindowManager
import android.view.inspector.WindowInspector
import android.os.Looper
import androidx.compose.runtime.Recomposer
import androidx.compose.ui.node.RootForTest
import androidx.compose.ui.platform.findViewTreeCompositionContext
import androidx.compose.ui.platform.ViewRootForTest
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsNode
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.text.AnnotatedString
import java.util.Collections
import java.util.WeakHashMap

/**
 * The semantics tree, read in the app's own process.
 *
 * `ViewRootForTest.onViewCreatedCallback` hands over every Compose root as
 * it is created, which is why this has to be armed before the first
 * `setContent` runs — see [SmixProbeProvider], which a content provider's
 * lifetime puts ahead of `Application.onCreate`.
 *
 * Roots are held weakly. A Compose root outliving its activity would keep
 * the whole hierarchy alive, and a probe that leaks the thing it observes
 * is worse than no probe.
 */
object SemanticsProbe {
    private val roots: MutableSet<ViewRootForTest> =
        Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap()))

    private var installed = false

    /** Arm the callback. Idempotent — a second call replaces nothing. */
    @Synchronized
    fun install() {
        if (installed) return
        installed = true
        val previous = ViewRootForTest.onViewCreatedCallback
        ViewRootForTest.onViewCreatedCallback = { root ->
            roots.add(root)
            // Compose UI Test sets this too, and an app running both should
            // not have one of them silently win.
            previous?.invoke(root)
        }
    }

    /**
     * How long the semantics tree has looked the same, in milliseconds.
     *
     * NOT `hasPendingMeasureOrLayout`, which was the first answer here and
     * is the wrong one. Measured 2026-08-27: it read `true` throughout an
     * active fling of a lazy list — it is only false during the microseconds
     * a layout pass is actually pending, so any sample taken across a
     * process boundary lands in the gap between them. A signal that is true
     * whether or not the screen is moving cannot end a wait.
     *
     * Quiescence is the question a waiter is really asking: has anything
     * changed lately. It is computed here, in the app's process, where
     * looking is cheap, and it needs nothing internal to Compose.
     *
     * Returns -1 when nothing has been seen yet — "not settled" and "never
     * looked" are different, and one value for both is how a waiter learns
     * to trust a number that means nothing.
     *
     * Only stillness the sampler saw counts: from the last change to the
     * last sample, not to now. The sampler runs on the main thread, and on
     * a starved device it ran up to 225 ms late (an emulator whose guest
     * CPUs were held by busy loops); counted to now, that time was added
     * to a stillness nobody had seen.
     */
    fun quiescentForMs(): Long {
        startSamplerOnce()
        synchronized(this) {
            return if (lastChangedAtMs == 0L) -1 else lastSampleAtMs - lastChangedAtMs
        }
    }

    /**
     * How long ago the sampler last looked, or -1 before it first has.
     * Well over [SAMPLE_INTERVAL_MS] means the main thread is not getting
     * to it, and [quiescentForMs] is as old as that.
     */
    fun sampleLateMs(): Long {
        startSamplerOnce()
        synchronized(this) {
            return if (lastSampleAtMs == 0L) -1 else System.currentTimeMillis() - lastSampleAtMs
        }
    }

    /**
     * Watch the tree on a timer rather than only when asked.
     *
     * Sampling at call time can only answer "different from what I last
     * saw" — it cannot say WHEN it changed. Measured: after a scroll, the
     * first ask three seconds later reported zero milliseconds of quiet,
     * because the change had happened at some unknown point in between.
     *
     * Not a draw listener, which would have been cheaper: a Compose text
     * field's caret blinks, and a screen with a focused input would then
     * never look still. The semantics fingerprint ignores that — a caret
     * changes no bounds, no text and no focus.
     *
     * Started on the first ask, so an app that carries the probe and never
     * uses it pays nothing.
     */
    private fun startSamplerOnce() {
        synchronized(this) {
            if (sampler != null) return
            val h = Handler(Looper.getMainLooper())
            sampler = h
            val tick = object : Runnable {
                override fun run() {
                    sample()
                    h.postDelayed(this, SAMPLE_INTERVAL_MS)
                }
            }
            h.post(tick)
        }
    }

    private fun sample() {
        val fp = try {
            attached()
                .map { it.semanticsRoot() }
                .fold(17) { acc, n -> acc * 31 + fingerprint(n) }
        } catch (_: Exception) {
            // A root torn down mid-walk is not a change worth recording,
            // and a sampler that dies takes the signal with it silently.
            return
        }
        val behind = synchronized(this) {
            lastSampleAtMs = System.currentTimeMillis()
            if (fp != lastFingerprint || lastChangedAtMs == 0L) {
                lastFingerprint = fp
                lastChangedAtMs = lastSampleAtMs
                false
            } else {
                (lastRead?.atMs ?: 0L) < lastChangedAtMs
            }
        }
        // Kept current for the read a busy main thread cannot take: once,
        // when the screen has held still for a tick after changing, and
        // only from a screen whose layout has caught up; see [read]. Not on
        // every change. A whole read on each tick of a scroll held the main
        // thread and this sampler with it, and a wait asking how long the
        // tree had been still was told 380 ms in the middle of the scroll.
        if (behind && !hasPendingLayout()) {
            try {
                readHere()
            } catch (_: Exception) {
                // the same root torn down mid-walk, met one step later
            }
        }
    }

    /** One whole reading of the screen: the tree and the display it is on. */
    class Reading(val json: String, val screenW: Int, val screenH: Int, val atMs: Long)

    @Volatile
    private var lastRead: Reading? = null

    /** The screen read now, on the main thread; see [MainThread]. */
    private fun readHere(): Reading {
        val (w, h) = screenSize()
        return Reading(dumpWireJson(), w, h, System.currentTimeMillis()).also { lastRead = it }
    }

    /**
     * The screen as the main thread has it, or — when the main thread does
     * not take the read within [waitMs] and [orKept] allows — the last
     * reading it made, if the screen has not changed since.
     *
     * A main thread that is busy is not laying anything out, so a reading
     * taken after the last change the sampler saw is still what is on
     * screen: an app that holds its main thread for four seconds after a
     * tap shows the screen it showed when it started, and a look in those
     * four seconds answers without waiting for it. A reading older than
     * that change is not given out. Given out regardless, on a player
     * screen whose detection boxes never stop moving it was a screen from
     * before the playback controls appeared, and a tap on them was judged
     * against it.
     */
    internal fun read(waitMs: Long, orKept: Boolean): MainThread.Ran<Reading> {
        startSamplerOnce()
        // A recomposition can replace nodes in one message and the layout
        // that places them runs in a later one; read between the two and
        // the replaced part is missing, because a node not yet placed is
        // left out. Measured on the fixture's tour screen: 1 read in 80.
        val ran = MainThread.run(waitMs, { !hasPendingLayout() }, ::readHere)
        if (ran !is MainThread.Ran.Busy || !orKept) return ran
        val kept = lastRead ?: return ran
        val changedAt = synchronized(this) { lastChangedAtMs }
        return if (kept.atMs >= changedAt) MainThread.Ran.Done(kept) else ran
    }

    private var sampler: Handler? = null
    private var lastFingerprint: Int? = null
    private var lastChangedAtMs: Long = 0
    private var lastSampleAtMs: Long = 0

    /** Fast enough to catch a fling, slow enough not to be the thing that moves. */
    private const val SAMPLE_INTERVAL_MS = 50L

    private fun fingerprint(node: SemanticsNode): Int {
        val c = node.config
        var h = node.id
        val o = node.positionOnScreen
        h = h * 31 + o.x.toInt()
        h = h * 31 + o.y.toInt()
        h = h * 31 + node.size.width
        h = h * 31 + node.size.height
        h = h * 31 + (c.getOrElseNullable(SemanticsProperties.Text) { null }?.toString()?.hashCode() ?: 0)
        h = h * 31 + (c.getOrElseNullable(SemanticsProperties.EditableText) { null }?.toString()?.hashCode() ?: 0)
        h = h * 31 + (c.getOrElseNullable(SemanticsProperties.Focused) { false }?.hashCode() ?: 0)
        for (child in node.children) h = h * 31 + fingerprint(child)
        return h
    }

    /**
     * The display's size, in the same pixels the node bounds are in.
     *
     * No longer the number anything divides by. The runner puts its own
     * display size on the probe tree it serves — the size it turns taps
     * back into pixels with — because a denominator measured in two
     * processes is two denominators, and the accessibility tree's had
     * already drifted from the runner's by 944 pixels under a dialog.
     * This is still sent for a runner older than that, which reads it.
     *
     * Reported because everything downstream normalises a node's rectangle
     * against the tree ROOT's, and the probe's roots cover only what
     * Compose occupies. Normalising a tap against that put it a fifth of a
     * screen off, and `/input-text` answered `no_focused_field` — a failure
     * whose message pointed at the keyboard rather than at the arithmetic.
     */
    fun screenSize(): Pair<Int, Int> {
        val v = attached().firstOrNull()?.view ?: return 0 to 0
        // `displayMetrics` is the app's USABLE area — it excludes the
        // status and navigation bars. The accessibility tree's root is the
        // whole display, and everything downstream divides by the root's
        // rectangle, so the two denominators differed by the height of the
        // system bars: 2072 against 2340, and a tap aimed thirteen percent
        // too far down. The button that opens a dialog was missed
        // silently, and the wait that followed timed out looking for
        // something that had never appeared.
        val wm = v.context.getSystemService(WindowManager::class.java)
            ?: return 0 to 0
        val b = wm.currentWindowMetrics.bounds
        return b.width() to b.height()
    }

    /** Every attached root's unmerged tree, as smix's wire spells it. */
    ///
    /// Roots are listed bottom of the window stack first — see [StackOrder].
    fun dumpWireJson(): String {
        val compose = attached()
        val composed = compose.mapNotNull { root ->
            val node = root.semanticsRoot().toProbeNode() ?: return@mapNotNull null
            // The Views this root hosts, each under the node that holds it
            // (see [HostedNesting]). `AndroidView` content has no semantics
            // node of its own, so it is reachable only from the View side —
            // and a probe that leaves it out sees LESS than the
            // accessibility path it replaces.
            val hosted = root.view.hostedViews()
            root.view to (if (hosted.isEmpty()) node else HostedNesting.nest(node, hosted))
        }
        // The Views each window draws beside its Compose roots, and the
        // roots of one window in the order that window draws them — see
        // [WindowSiblings].
        val withSiblings = composed.groupBy { it.first.rootView }.flatMap { (window, inWindow) ->
            val index = inWindow.withIndex().associate { (i, item) -> item.first to i }
            WindowSiblings.attach(inWindow.map { it.second }, WindowSiblings.walk(window, index))
                .map { window to it }
        }
        val windows = WindowInspector.getGlobalWindowViews()
        val stacked = StackOrder.bottomFirst(withSiblings + windowsWithoutCompose(compose), { it.first }, windows)
        return Occlusion.prune(
            stacked.map { (window, root) -> opaqueFace(window) to root.copy(modal = takesEveryTouch(window)) },
        ).toWireJson()
    }

    /** Whether the window `root` stands for takes every touch on the screen. */
    private fun takesEveryTouch(root: View): Boolean {
        val params = root.layoutParams as? WindowManager.LayoutParams ?: return false
        val passesThrough = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        return params.flags and passesThrough == 0
    }

    /** Where a window's root paints opaquely on screen, or null if it does not. */
    private fun opaqueFace(window: View): Bounds? {
        if (!window.isOpaque) return null
        val at = IntArray(2)
        window.getLocationOnScreen(at)
        return Bounds(at[0], at[1], at[0] + window.width, at[1] + window.height)
    }

    /** The signal that was tried first, kept so its verdict can be re-checked. */
    fun hasPendingLayout(): Boolean = attached().any { it.hasPendingMeasureOrLayout }

    /**
     * Whether a Compose root has work waiting for a frame: an animation in
     * flight (a fling, a transition) or a recomposition not yet run. A
     * still tree alone cannot tell the end of a fling from a gap between
     * two of its frames; this can. Measured on the fixture's list: true at
     * most readings through a fling, false between frames now and then,
     * and false through a drag — a finger, not an animation, moves the
     * list then, and a drag the device injects slowly holds it still.
     *
     * Null when the app's Compose has no recomposer this can read.
     */
    fun framesPending(): Boolean? = try {
        val states = attached().mapNotNull {
            (it.view.findViewTreeCompositionContext() as? Recomposer)?.currentState?.value
        }
        if (states.isEmpty()) null else states.any { it == Recomposer.State.PendingWork }
    } catch (_: LinkageError) {
        null
    }

    /** Whether anything is there to read — the honest answer to "is the probe live". */
    fun rootCount(): Int = attached().size

    /**
     * Actions the probe will perform, and the ones it refuses.
     *
     * **The probe stages the screen; the touch stays real.**
     *
     * Measured on the fixture, 2026-08-27, with a dialog's scrim over
     * `compose_submit`: a real touch at that node's screen coordinates left
     * the app unchanged — correctly blocked — while semantics `OnClick`
     * returned true and the submit went through. A semantics action calls
     * the composable's own lambda and nothing in that path does hit-testing.
     *
     * Offering it as smix's tap would manufacture passes for taps a user
     * could not make, which is worse than the false-pass class the error
     * guide already names: there, an action did nothing and said it worked;
     * here, an impossible action works.
     *
     * So the surface is only what PREPARES a real touch — bringing a row
     * that was never composed into existence — after which the touch does
     * the touching. `unsafeAct` exists so the refusal above can be shown to
     * be refusing something real, and is not on the offered surface.
     */
    fun act(tag: String, action: String): String = when (action) {
        in STAGING_ACTIONS -> performOnMain(tag, action)
        "OnClick", "PerformImeAction", "SetText" ->
            "the probe refuses `$action`: it calls the composable's lambda " +
                "without hit-testing, so it fires on a node nothing could " +
                "touch. Use smix's own tap/fill — the probe is for staging " +
                "the screen, not for acting on it."
        else -> "unknown action: $action"
    }

    /** The refused half, reachable only so a gate can show what it refuses. */
    fun unsafeAct(tag: String, action: String): String = performOnMain(tag, action)

    /** An action runs what the composable would run, so it runs where that does. */
    private fun performOnMain(tag: String, action: String): String =
        when (val ran = MainThread.run(ACT_WAIT_MS) { perform(tag, action) }) {
            is MainThread.Ran.Done -> ran.value
            is MainThread.Ran.Threw -> "the action threw on the app's main thread: ${ran.error}"
            MainThread.Ran.Busy -> "the app's main thread did not take the action within $ACT_WAIT_MS ms"
        }

    private const val ACT_WAIT_MS = 3000L

    /** Actions that bring a node within reach of a real touch. */
    val STAGING_ACTIONS = setOf("ScrollToIndex", "ScrollBy")

    private fun perform(tag: String, action: String): String {
        val node = attached()
            .asSequence()
            .map { it.semanticsRoot() }
            .mapNotNull { find(it, tag) }
            .firstOrNull()
            ?: return "no node carries the tag `$tag`"
        val c = node.config
        return when (action) {
            "OnClick" -> c.getOrElseNullable(SemanticsActions.OnClick) { null }
                ?.action?.invoke()
                ?.let { "OnClick returned $it" }
                ?: "this node has no OnClick action"
            else -> "unknown action: $action"
        }
    }

    private fun find(node: SemanticsNode, tag: String): SemanticsNode? {
        if (node.config.getOrElseNullable(SemanticsProperties.TestTag) { null } == tag) return node
        for (c in node.children) find(c, tag)?.let { return it }
        return null
    }

    /// The unmerged tree of one root. Third use of the same cast chain.
    private fun ViewRootForTest.semanticsRoot(): SemanticsNode =
        (this as RootForTest).semanticsOwner.unmergedRootSemanticsNode

    // Shown as well as attached: an activity that has gone behind another
    // keeps its window attached with nothing on screen. Measured on the
    // fixture, 2026-09-30: with the watch screen stopped behind the main
    // one, the probe served the watch screen's tree, and `tapOn` looked for
    // the main screen's button in it. `windowsWithoutCompose` has always
    // asked both.
    private fun attached(): List<ViewRootForTest> =
        synchronized(roots) { roots.toList() }.filter { it.view.isAttachedToWindow && it.view.isShown }
}

internal fun SemanticsNode.toProbeNode(): ProbeNode? {
    // A node nobody has placed has no position, and reporting one means
    // inventing it. A `LazyColumn` composes rows ahead of the ones it
    // shows; `children` hands them over (it filters on attached and
    // deactivated, not on placed — bytecode, Compose 1.9.3), and their
    // coordinates are from wherever the layout last considered putting
    // them. A consumer's `scrollUntilVisible` stopped on one of those and
    // the tap that followed landed on the filter chips.
    if (!layoutInfo.isPlaced) return null
    val c = config
    // Screen coordinates, not `boundsInWindow`.
    //
    // A dialog composes into its OWN window, and `boundsInWindow` is
    // relative to whichever window the node is in — so the fixture's dialog
    // reported itself at y=0 and the status bar's clock landed geometrically
    // "inside" it. Anything that compares two roots, or turns a node into a
    // tap, needs one coordinate space, and the only one shared across
    // windows is the screen's.
    val origin = positionOnScreen
    val dimensions = size
    val left = origin.x.toInt()
    val top = origin.y.toInt()
    val layout = Bounds(left, top, left + dimensions.width, top + dimensions.height)
    // The window's origin on screen, from this node's own two positions.
    val inWindow = positionInWindow
    val clipped = boundsInWindow
    val shown = visibleScreenRect(
        layoutOnScreen = layout,
        clippedInWindow = Bounds(
            clipped.left.toInt(),
            clipped.top.toInt(),
            clipped.right.toInt(),
            clipped.bottom.toInt(),
        ),
        windowLeftOnScreen = (origin.x - inWindow.x).toInt(),
        windowTopOnScreen = (origin.y - inWindow.y).toInt(),
    )
    // What the node will accept, rather than what a toolkit says it is.
    // `isEditable` is a claim; taking SetText is a fact.
    val actions = c.mapNotNull { entry ->
        entry.key.name.takeIf { entry.value is androidx.compose.ui.semantics.AccessibilityAction<*> }
    }.sorted()
    return ProbeNode(
        id = id,
        testTag = c.getOrElseNullable(SemanticsProperties.TestTag) { null },
        resourceId = null,
        // A label's text is a list because a node can carry several runs.
        text = c.getOrElseNullable(SemanticsProperties.Text) { null }
            ?.joinToString("") { it.text }
            ?.ifEmpty { null },
        // Compose semantics has no hint property to read.
        hint = null,
        // What a field actually holds. The accessibility projection cannot
        // report this on a masked field — it gives one bullet per character
        // and the characters nowhere.
        editableText = c.getOrElseNullable(SemanticsProperties.EditableText) { null }
            ?.let(AnnotatedString::toString),
        inputText = c.getOrElseNullable(SemanticsProperties.InputText) { null }
            ?.let(AnnotatedString::toString),
        contentDescription = c.getOrElseNullable(SemanticsProperties.ContentDescription) { null }
            ?.joinToString(", ")
            ?.ifEmpty { null },
        role = c.getOrElseNullable(SemanticsProperties.Role) { null }?.toString(),
        className = null,
        bounds = layout,
        visibleBounds = shown,
        // Compose keeps focus in its own semantics layer. Asking the
        // accessibility side instead is the wrong instrument, and reading
        // it as "nothing has focus" cost a consumer their whole suite.
        focused = c.getOrElseNullable(SemanticsProperties.Focused) { false } ?: false,
        enabled = !c.contains(SemanticsProperties.Disabled),
        visible = shown.right > shown.left && shown.bottom > shown.top,
        actions = actions,
        children = children.mapNotNull { it.toProbeNode() },
        touch = Touch.ofCompose(Touch.hasPointerInput(layoutInfo)),
    )
}
