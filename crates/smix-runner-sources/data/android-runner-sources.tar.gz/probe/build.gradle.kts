// smix-probe — the optional in-process probe.
//
// smix perceives through the accessibility tree, which is a lossy,
// asynchronous projection of what the UI toolkit knows. For a Compose app
// that projection is a bad one: the whole UI is a single
// `AndroidComposeView` and the nodes are synthesised from semantics, so a
// `testTag` only arrives at all when the app opted in with
// `testTagsAsResourceId`, dialogs host in a separate window that the opt-in
// does not reach, and a masked field's text reads back as bullets.
//
// This module is how an app hands smix the semantics tree instead. It is
// `debugImplementation` — never in a release build — and it is optional:
// without it everything works exactly as before, and `/tree` says so
// rather than quietly answering worse.
plugins {
    id("com.android.library")
    // Published: the guides tell a consumer to write
    // `debugImplementation("jp.golia.smix:smix-probe:…")`, and a line that
    // resolves to nothing is worse than no line at all.
    id("com.vanniktech.maven.publish")
}

group = "jp.golia.smix"
version = providers.gradleProperty("smixVersion").get()

android {
    namespace = "dev.smix.probe"
    compileSdk = 37
    defaultConfig {
        minSdk = 33
        // What an app compiling against this needs: its minSdk already
        // demands 33. Left unset, AGP 9 writes this library's own compileSdk
        // here, and every app below it fails to build for no reason in the
        // code.
        aarMetadata { minCompileSdk = 33 }
        // What the host compares with its own version: an app keeps the
        // probe it was built with until someone raises the dependency.
        buildConfigField("String", "SMIX_VERSION", "\"${providers.gradleProperty("smixVersion").get()}\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

mavenPublishing {
    publishToMavenCentral(automaticRelease = true)
    signAllPublications()
    coordinates("jp.golia.smix", "smix-probe", providers.gradleProperty("smixVersion").get())
    pom {
        name.set("smix-probe")
        description.set(
            "Optional in-process probe for smix — lets an Android app hand " +
                "smix its Compose semantics tree instead of the accessibility " +
                "projection. Debug builds only."
        )
        url.set("https://github.com/goliajp/smix")
        licenses {
            license {
                name.set("Apache-2.0 OR MIT")
                distribution.set("repo")
            }
        }
        developers {
            developer {
                id.set("doracawl")
                name.set("GOLIA K.K.")
                email.set("lihao@golia.jp")
            }
        }
        scm {
            url.set("https://github.com/goliajp/smix")
            connection.set("scm:git:git://github.com/goliajp/smix.git")
            developerConnection.set("scm:git:ssh://git@github.com/goliajp/smix.git")
        }
    }
}

dependencies {
    // compileOnly, and no BOM: the app already has Compose on its
    // classpath and the probe must not drag a second copy in — nor pull
    // the BOM's constraints into a module that links against nothing.
    // The floor is the version that first published the API this reads.
    compileOnly("androidx.compose.ui:ui:1.12.1")
    testImplementation("junit:junit:4.13.2")
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        // Published: the Kotlin metadata stays readable by the compilers
        // that could read it before this library was built with 2.4.
        languageVersion.set(org.jetbrains.kotlin.gradle.dsl.KotlinVersion.KOTLIN_2_0)
        apiVersion.set(org.jetbrains.kotlin.gradle.dsl.KotlinVersion.KOTLIN_2_0)
    }
}
