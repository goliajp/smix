// /tree wire assembly: android class → smix Role mapping, resource-id
// short strip, A11yNode JSON shape (camelCase field names are the
// contract with smix-screen's A11yNode deserializer), virtual window
// root.

package dev.smix.runner

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TreeWireTest {

    // MARK: - leavesHollow

    // The app's window is replaced by the probe's view of it on the
    // host, so the reader walks it only when nobody asked for it hollow —
    // and only the app's own application window is ever left hollow.
    @Test
    fun onlyTheNamedAppsApplicationWindowIsLeftHollow() {
        assertTrue(TreeWire.leavesHollow(1, "dev.smix.fixture", "dev.smix.fixture"))
        assertFalse(TreeWire.leavesHollow(1, "dev.smix.fixture", null))
        assertFalse(TreeWire.leavesHollow(1, "com.other.app", "dev.smix.fixture"))
        // The keyboard and the system bars are what the host reads this
        // tree for; they are walked whatever the request says.
        assertFalse(TreeWire.leavesHollow(2, "dev.smix.fixture", "dev.smix.fixture"))
        assertFalse(TreeWire.leavesHollow(3, "dev.smix.fixture", "dev.smix.fixture"))
        // A package the platform did not report is not the app's.
        assertFalse(TreeWire.leavesHollow(1, null, "dev.smix.fixture"))
    }

    // MARK: - deriveRole

    @Test
    fun deriveRoleMapsWidgetClasses() {
        assertEquals("button", TreeWire.deriveRole("android.widget.Button"))
        assertEquals("button", TreeWire.deriveRole("android.widget.ImageButton"))
        assertEquals("button", TreeWire.deriveRole("androidx.appcompat.widget.AppCompatButton"))
        assertEquals("textField", TreeWire.deriveRole("android.widget.EditText"))
        assertEquals("textField", TreeWire.deriveRole("androidx.appcompat.widget.AppCompatEditText"))
        assertEquals("image", TreeWire.deriveRole("android.widget.ImageView"))
        assertEquals("switch", TreeWire.deriveRole("android.widget.Switch"))
        assertEquals("switch", TreeWire.deriveRole("androidx.appcompat.widget.SwitchCompat"))
        assertEquals("checkBox", TreeWire.deriveRole("android.widget.CheckBox"))
        assertEquals("radio", TreeWire.deriveRole("android.widget.RadioButton"))
        assertEquals("switch", TreeWire.deriveRole("android.widget.ToggleButton"))
        assertEquals("staticText", TreeWire.deriveRole("android.widget.TextView"))
        assertEquals("staticText", TreeWire.deriveRole("androidx.appcompat.widget.AppCompatTextView"))
        assertEquals("scrollView", TreeWire.deriveRole("androidx.recyclerview.widget.RecyclerView"))
        assertEquals("scrollView", TreeWire.deriveRole("android.widget.ListView"))
        assertEquals("tabBar", TreeWire.deriveRole("com.google.android.material.tabs.TabLayout"))
        assertEquals("tabBar", TreeWire.deriveRole("android.widget.TabHost"))
        assertEquals("navigationBar", TreeWire.deriveRole("androidx.appcompat.widget.Toolbar"))
        assertEquals("webView", TreeWire.deriveRole("android.webkit.WebView"))
    }

    @Test
    fun deriveRoleUnknownClassReturnsNull() {
        assertNull(TreeWire.deriveRole("android.view.View"))
        assertNull(TreeWire.deriveRole("android.widget.FrameLayout"))
        assertNull(TreeWire.deriveRole(""))
    }

    // MARK: - shortResourceId

    @Test
    fun shortResourceIdStripsPackagePrefix() {
        assertEquals("submit-btn", TreeWire.shortResourceId("com.example.app:id/submit-btn"))
        assertEquals("submit-btn", TreeWire.shortResourceId("submit-btn"))
    }

    // MARK: - nodeJson

    @Test
    fun nodeJsonFullShape() {
        val obj = TreeWire.nodeJson(
            rawType = "android.widget.Button",
            identifier = "com.example.app:id/submit-btn",
            label = "Submit",
            text = "Submit now",
            placeholder = null,
            x = 10,
            y = 20,
            w = 100,
            h = 40,
            enabled = true,
            selected = false,
            hasFocus = true,
            visible = true,
            children = JSONArray(),
        )
        assertEquals("android.widget.Button", obj.getString("rawType"))
        assertEquals("button", obj.getString("role"))
        assertEquals("submit-btn", obj.getString("identifier"))
        assertEquals("Submit", obj.getString("label"))
        assertEquals("Submit now", obj.getString("text"))
        val bounds = obj.getJSONObject("bounds")
        assertEquals(10, bounds.getInt("x"))
        assertEquals(20, bounds.getInt("y"))
        assertEquals(100, bounds.getInt("w"))
        assertEquals(40, bounds.getInt("h"))
        assertTrue(obj.getBoolean("enabled"))
        assertFalse(obj.getBoolean("selected"))
        assertTrue(obj.getBoolean("hasFocus"))
        assertTrue(obj.getBoolean("visible"))
        assertEquals(0, obj.getJSONArray("children").length())
    }

    @Test
    fun nodeJsonOmitsEmptyOptionalFieldsAndUnknownRole() {
        val obj = TreeWire.nodeJson(
            rawType = "android.view.View",
            identifier = null,
            label = "",
            text = null,
            placeholder = null,
            x = 0,
            y = 0,
            w = 0,
            h = 0,
            enabled = true,
            selected = false,
            hasFocus = false,
            visible = false,
            children = JSONArray(),
        )
        assertFalse(obj.has("role"))
        assertFalse(obj.has("identifier"))
        assertFalse(obj.has("label"))
        assertFalse(obj.has("text"))
    }

    @Test
    fun nodeJsonClampsNegativeExtentsToZero() {
        val obj = TreeWire.nodeJson(
            rawType = "android.view.View",
            identifier = null,
            label = null,
            text = null,
            placeholder = null,
            x = 5,
            y = 6,
            w = -3,
            h = -1,
            enabled = true,
            selected = false,
            hasFocus = false,
            visible = false,
            children = JSONArray(),
        )
        val bounds = obj.getJSONObject("bounds")
        assertEquals(0, bounds.getInt("w"))
        assertEquals(0, bounds.getInt("h"))
    }

    @Test
    fun nodeJsonNestsChildren() {
        val child = TreeWire.nodeJson(
            rawType = "android.widget.TextView",
            identifier = null,
            label = null,
            text = "hi",
            placeholder = null,
            x = 0, y = 0, w = 10, h = 10,
            enabled = true, selected = false, hasFocus = false, visible = true,
            children = JSONArray(),
        )
        val obj = TreeWire.nodeJson(
            rawType = "android.widget.FrameLayout",
            identifier = null,
            label = null,
            text = null,
            placeholder = null,
            x = 0, y = 0, w = 100, h = 100,
            enabled = true, selected = false, hasFocus = false, visible = true,
            children = JSONArray().put(child),
        )
        val children = obj.getJSONArray("children")
        assertEquals(1, children.length())
        assertEquals("hi", children.getJSONObject(0).getString("text"))
    }

    // MARK: - windowRootJson

    @Test
    fun windowRootJsonShape() {
        val root = TreeWire.windowRootJson(1080, 2400, JSONArray().put(JSONObject()))
        assertEquals("android.view.WindowRoot", root.getString("rawType"))
        val bounds = root.getJSONObject("bounds")
        assertEquals(0, bounds.getInt("x"))
        assertEquals(0, bounds.getInt("y"))
        assertEquals(1080, bounds.getInt("w"))
        assertEquals(2400, bounds.getInt("h"))
        assertTrue(root.getBoolean("enabled"))
        assertFalse(root.getBoolean("selected"))
        assertFalse(root.getBoolean("hasFocus"))
        assertTrue(root.getBoolean("visible"))
        assertEquals(1, root.getJSONArray("children").length())
    }

    // MARK: - windowJson
    //
    // Each window's root carries whose it is. Without it the host could not
    // tell the app's nodes from the status bar's, and a failure that listed
    // "the first ten visible elements" listed the clock. The kind strings
    // are the contract with smix-screen's `WindowKind` (camelCase).

    @Test
    fun anApplicationWindowSaysWhoseItIsAndWhetherItHasTheFocus() {
        val w = TreeWire.windowJson(windowType = 1, pkg = "dev.smix.fixture", focused = true, layer = 2, touchable = listOf(intArrayOf(0, 0, 1080, 2400)))
        assertTrue("an application window names its package: $w", w.has("package"))
        assertEquals("dev.smix.fixture", w.getString("package"))
        assertEquals("application", w.getString("kind"))
        assertTrue(w.getBoolean("focused"))
    }

    @Test
    fun theKindFollowsTheWindowType() {
        assertEquals("inputMethod", TreeWire.windowJson(2, "com.android.inputmethod", false, 0, emptyList()).getString("kind"))
        assertEquals("system", TreeWire.windowJson(3, "com.android.systemui", false, 0, emptyList()).getString("kind"))
        assertEquals("other", TreeWire.windowJson(4, null, false, 0, emptyList()).getString("kind"))
        assertEquals("other", TreeWire.windowJson(6, null, false, 0, emptyList()).getString("kind"))
    }

    // Where the window stands in the stack. The order windows are listed
    // in is not the order on screen, and the host needs to know which
    // window is over which to aim a touch at the part of an element that
    // nothing covers (an app drawn edge to edge, under the status bar).
    @Test
    fun aWindowSaysWhereItStandsInTheStack() {
        val bar = TreeWire.windowJson(windowType = 3, pkg = "com.android.systemui", focused = false, layer = 21, touchable = listOf(intArrayOf(0, 0, 1080, 136)))
        val app = TreeWire.windowJson(windowType = 1, pkg = "dev.smix.fixture", focused = true, layer = 2, touchable = listOf(intArrayOf(0, 0, 1080, 2400)))
        assertTrue("the window's layer is on the wire: $bar", bar.has("layer"))
        assertEquals(21, bar.optInt("layer", -1))
        assertEquals(2, app.optInt("layer", -1))
    }

    // Where it takes touches, which is not its bounds. Measured on API 36:
    // the keyboard's window spans 136..2340, every pixel below the status
    // bar, and a host that took that for the part it covers refused every
    // tap in the app while the keyboard was up.
    @Test
    fun aWindowSaysWhereItTakesTouches() {
        val ime = TreeWire.windowJson(
            windowType = 2, pkg = "com.google.android.inputmethod.latin", focused = false,
            layer = 1, touchable = listOf(intArrayOf(0, 1500, 1080, 840)),
        )
        assertTrue("where the window takes touches is on the wire: $ime", ime.has("touchable"))
        val t = ime.getJSONObject("touchable")
        assertEquals(listOf(0, 1500, 1080, 840), listOf("x", "y", "w", "h").map { t.getInt(it) })
    }

    // Measured on API 36 after a stylus stroke: the keyboard took touches on
    // a toolbar by the field and a strip at the bottom, and a real touch
    // between them, inside the rectangle around both, opened the app's code
    // screen. A host that had only that rectangle refused the tap.
    @Test
    fun aWindowThatTakesTouchesInPiecesListsEachPiece() {
        val ime = TreeWire.windowJson(
            windowType = 2, pkg = "com.google.android.inputmethod.latin", focused = false,
            layer = 1, touchable = listOf(intArrayOf(22, 847, 154, 732), intArrayOf(0, 2274, 1080, 66)),
        )
        val pieces = ime.getJSONArray("touchableRects")
        assertEquals(
            listOf(listOf(22, 847, 154, 732), listOf(0, 2274, 1080, 66)),
            (0 until pieces.length()).map { i -> listOf("x", "y", "w", "h").map { pieces.getJSONObject(i).getInt(it) } },
        )
        val t = ime.getJSONObject("touchable")
        assertEquals(listOf(0, 847, 1080, 1493), listOf("x", "y", "w", "h").map { t.getInt(it) })
    }

    @Test
    fun aWindowThatTakesNoTouchesSaysNone() {
        val w = TreeWire.windowJson(windowType = 3, pkg = null, focused = false, layer = 0, touchable = emptyList())
        assertEquals(0, w.getJSONArray("touchableRects").length())
        assertEquals(listOf(0, 0, 0, 0), listOf("x", "y", "w", "h").map { w.getJSONObject("touchable").getInt(it) })
    }

    @Test
    fun aPackageNobodyReportedIsLeftOutRatherThanGuessed() {
        val w = TreeWire.windowJson(windowType = 3, pkg = null, focused = false, layer = 0, touchable = emptyList())
        assertFalse(w.has("package"))
        assertFalse(w.getBoolean("focused"))
    }

    @Test
    fun aWindowTheProbeNamedIsHollowWithoutItsRoot() {
        assertTrue(TreeWire.hollowById(1, 42, setOf(42, 43)))
        assertFalse("an id the probe did not give", TreeWire.hollowById(1, 44, setOf(42, 43)))
        assertFalse("only an application window", TreeWire.hollowById(3, 42, setOf(42)))
        assertFalse("no probe answer, nothing matched", TreeWire.hollowById(1, 42, emptySet()))
    }
}
