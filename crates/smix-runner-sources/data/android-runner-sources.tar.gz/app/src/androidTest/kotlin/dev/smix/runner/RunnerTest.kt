// smix-android-runner entry + HTTP surface (/health, /tree, tap, swipe,
// press-key, popups, etc.).
//
// Launched via:
//   adb shell am instrument -w -e debug false \
//     -e class dev.smix.runner.RunnerTest \
//     dev.smix.runner.test/androidx.test.runner.AndroidJUnitRunner
//
// /health   — minimal alive probe
// /tree     — UiAutomator2 window walk → A11yNode JSON tree
// (see the SmixHttpServer.serve dispatch table for the full route list)

package dev.smix.runner

import android.os.Build
import android.app.UiAutomation
import android.graphics.Rect
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch as JCountDownLatch
import java.util.concurrent.TimeUnit
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.Configurator
import androidx.test.uiautomator.UiDevice
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Test
import org.junit.runner.RunWith
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch

@RunWith(AndroidJUnit4::class)
class RunnerTest {
    @Test
    fun runServerForever() {
        val inst = InstrumentationRegistry.getInstrumentation()
        val device = UiDevice.getInstance(inst)
        // Without FLAG_RETRIEVE_INTERACTIVE_WINDOWS,
        // UiAutomation.getWindows() returns only the instrumentation
        // window (status_bar / nav_bar) and filters out the foreground
        // SUT window, so /tree dumps come back empty of app content.
        // Setting this flag at AccessibilityServiceInfo level lets us
        // walk all interactive windows including the SUT.
        //
        // FLAG_REPORT_VIEW_IDS is required for
        // findAccessibilityNodeInfosByViewId to match by resource-id
        // exactly. Without it, viewIdResourceName surfaces on individual
        // nodes (tree dump still gets ids) but the lookup-by-id API
        // silently returns empty, forcing every tap to fall through to
        // the touch path — which fires onClick reliably for top-level
        // Buttons but loses Compose's per-recompose registration race
        // for chained NavHost transitions.
        val info = inst.uiAutomation.serviceInfo
        info.flags = info.flags or
            android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
            android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        // The recorder (v2.10-C2) listens on the AccessibilityEvent stream; open
        // the two event types it maps so the listener is delivered them. Whether
        // this needs widening further, and whether it perturbs waitForIdle, is
        // proven on the emulator in the C2-S3 e2e (source-only cannot decide it).
        info.eventTypes = info.eventTypes or
            android.view.accessibility.AccessibilityEvent.TYPE_VIEW_CLICKED or
            android.view.accessibility.AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
        inst.uiAutomation.serviceInfo = info
        // Feed captured events to RecordBuffer while a recording is active. The
        // buffer drops them until /record/start, so this is cheap when idle.
        inst.uiAutomation.setOnAccessibilityEventListener { ev ->
            RecordBuffer.append(
                CapturedAxEvent(
                    type = ev.eventType,
                    viewId = ev.source?.viewIdResourceName,
                    text = ev.text.joinToString(""),
                    beforeText = ev.beforeText?.toString(),
                    eventTimeMs = ev.eventTime,
                ),
            )
        }
        val server = SmixHttpServer(PORT, device, inst)
        server.setServerSocketFactory { NoDelayServerSocket() }
        server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, /* daemon = */ false)
        CountDownLatch(1).await()
    }

    companion object {
        const val PORT = 28080
    }
}

class SmixHttpServer(
    port: Int,
    private val device: UiDevice,
    private val instrumentation: android.app.Instrumentation,
) : NanoHTTPD(port) {
    // How many deletes the fallback clear sends when no focused
    // editable node answers. A bound, not a guarantee: a longer field
    // survives it, which is why `/clear-text` reports which path ran.
    private val FALLBACK_DELETE_COUNT = 64

    /// Delete keys per shell command in the fallback, so the route can stop
    /// between commands when its limit runs out.
    private val DELETE_BATCH = 16

    // /tree serve counter for the X-Tree-Snapshot-Refresh-Count
    // header (parity with the iOS runner).
    private val treeServeCounter = java.util.concurrent.atomic.AtomicLong(0)

    // Rate-limit screenshots (parity with the iOS pacer). A tight OCR
    // loop otherwise contends with UiAutomator; the floor is cheap
    // insurance. Elapsed-realtime clock so it is monotonic across the
    // process. See ScreenshotPacer.
    private val screenshotPacer = ScreenshotPacer(nowMs = { android.os.SystemClock.elapsedRealtime() })

    /**
     * Take a screenshot through the pacer: wait out the interval floor,
     * shoot, and record the wall time (and any failure, which opens the
     * pacer's circuit). Returns null on a failed capture, same as the
     * raw call. A backpressure decision still waits here rather than
     * erroring, so the caller's contract is unchanged.
     */
    private fun pacedScreenshot(): android.graphics.Bitmap? {
        when (val d = screenshotPacer.computeWait()) {
            is PacerDecision.Wait -> if (d.ms > 0) Thread.sleep(d.ms)
            is PacerDecision.Backpressure -> Thread.sleep(d.retryAfterMs)
        }
        val start = android.os.SystemClock.elapsedRealtime()
        val bmp = instrumentation.uiAutomation.takeScreenshot()
        screenshotPacer.record(
            android.os.SystemClock.elapsedRealtime() - start,
            failed = bmp == null,
        )
        return bmp
    }

    /**
     * `GET /screenshot` — the whole screen as PNG bytes.
     *
     * The same wire contract the iOS runner has served all along: raw
     * bytes with `image/png`, and a 503 when the capture produced
     * nothing, which is a different thing from a screen that is blank.
     * There was no such route here, so `smix tap --then-screenshot`
     * answered `501 not_implemented` on Android while the very same
     * capture was already being taken for OCR one function above.
     *
     * Through the pacer, like every other capture in this process: a
     * caller alternating frames and OCR otherwise contends with
     * UiAutomator through two different doors.
     */
    private fun serveScreenshot(): Response {
        val bitmap = pacedScreenshot()
            ?: return errorJson(
                Response.Status.SERVICE_UNAVAILABLE,
                "screenshot_failed",
                "UiAutomation.takeScreenshot returned null. The screen was not " +
                    "photographed, which is not the same as a screen with " +
                    "nothing on it.",
            )
        val bytes = java.io.ByteArrayOutputStream().use { out ->
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
            bitmap.recycle()
            out.toByteArray()
        }
        return newFixedLengthResponse(
            Response.Status.OK,
            "image/png",
            ByteArrayInputStream(bytes),
            bytes.size.toLong(),
        )
    }

    /// How long `input-text` waits for a field to take focus.
    ///
    /// The tap that focuses it lands immediately before, and on a cold
    /// screen the IME needs a moment.
    ///
    /// This said "two seconds is well past what that takes on
    /// emulator-5554" and that had stopped being true. Measured
    /// 2026-08-31 on a freshly booted emulator-5554: tap the Settings
    /// search bar, and `mInputShown` flips at t=2s -- exactly the budget,
    /// so whether a caller got a focused field was a coin toss. What came
    /// out was `no_focused_field`, a sentence about this contract, from a
    /// release gate that is about whether a flag changed the driver's
    /// path.
    ///
    /// Six seconds instead: three times the slowest arrival measured
    /// here, and still short enough that a genuinely unfocused field
    /// fails while the caller is watching rather than at some timeout
    /// nobody will sit through. A budget set to the measurement is a
    /// budget that fails half the time.
    private val FOCUS_SETTLE_MS = 6000L

    /// How long to keep watching for the characters to appear.
    ///
    /// The field publishes to its accessibility node asynchronously, so
    /// this is a deadline on an event that has usually already
    /// happened, not a settle everyone pays. A fill that lands returns
    /// as soon as the reading matches — typically on the first look.
    private val TEXT_LAND_MS = 2000L

    /// How long to wait for the IME window to leave after back.
    ///
    /// Sibling of `BACK_SETTLE_MS` below and deliberately not merged
    /// with it: both watch for something after a back key, but they
    /// watch different things — the keyboard's window leaving, versus
    /// the screen behind it changing. One parameterised loop would make
    /// the reader work out which question it was asking today.
    private val KEYBOARD_GONE_MS = 2000L

    /// How long `/back` watches the screen before giving up, and how
    /// often it looks. The iOS runner's notes record that looking less
    /// often (250ms) was measured and came back worse.
    private val BACK_SETTLE_MS = 2000L
    private val BACK_POLL_MS = 50L

    /// How long the screen must read the same before the back key goes
    /// in, and how long `/back` waits for that. A tap's navigation can
    /// still be landing when the next step's back arrives — see
    /// `BeforeSettle`. The wait covers an activity a loaded emulator
    /// takes three seconds to make readable, and leaves the settle and
    /// both deep readings inside the route's limit.
    private val BACK_STILL_MS = 300L
    private val BACK_BEFORE_MS = 6000L

    /// How long to wait for the display to reach the rotation asked
    /// for.
    private val ROTATION_ARRIVES_MS = 3000L

    /// How long to wait for the named package to own the foreground.
    private val FOREGROUND_ARRIVES_MS = 3000L

    /// The bound on one screen-structure reading — see `structureHash`.
    ///
    /// Per window, and a constant. It was a total cap divided by how
    /// many windows were on screen, which put "how many windows are
    /// there today" inside every window's hash: one transient window
    /// appearing moved the budget, and unrelated windows then read
    /// differently while nothing about them had changed. A reading must
    /// not depend on the instrument's own state.
    ///
    /// Spending it per window rather than in window order is the part
    /// worth keeping: a single shared budget was eaten by the status
    /// and navigation bars, which sort first by id, and the app's
    /// window never got looked at.
    private val STRUCTURE_DEPTH_CAP = 4
    private val STRUCTURE_WINDOW_BUDGET = 40

    /// The whole-tree reading `/back` takes before the key and at its
    /// deadline — see `deepVerdict`. Bounded only so a runaway tree
    /// cannot hold the route.
    private val DEEP_WINDOW_BUDGET = 5000

    /// How many more whole-tree readings `/back` takes, looking for two in
    /// a row that agree, before it gives up on having one to judge with.
    private val DEEP_STEADY_TRIES = 3

    // NanoHTTPD serves each connection on its own thread, so the body
    // drained in `serve` reaches that request's handler and no other.
    private val drainedBody = ThreadLocal<String>()

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        // Drain the request body before routing, always.
        //
        // NanoHTTPD keeps the connection alive and does NOT consume an
        // unread body, so the leftover bytes become the front of the next
        // request line on the same socket. Four handlers took no session
        // and so never read theirs (/back, /hide-keyboard,
        // /session/close-all, /session/list) — every one of them is
        // POSTed with `{}`, and the request that followed died with
        // `HTTP verb {}GET unhandled`. Found by running a flow on an
        // emulator; no unit test can see it, because the defect is in
        // the connection's state rather than in any one message.
        //
        // Draining here rather than in each handler makes it structural:
        // a new POST route cannot forget.
        drainedBody.remove()
        if (session.method == Method.POST || session.method == Method.PUT) {
            drainedBody.set(RequestBody.read(session.inputStream, session.headers["content-length"]?.toLongOrNull()))
        }
        // Each route leaves one line in the device log — when it came in,
        // what it answered, how long it took and, for a route that keeps a
        // clock, each stage — so a route that ran long can be read back
        // after the fact.
        val arrived = android.os.SystemClock.elapsedRealtime()
        RouteLog.current.remove()
        val response = try {
            when {
                // LONGEST WAIT /health: 0 ms
                uri == "/health" && session.method == Method.GET -> serveHealth()
                // LONGEST WAIT /record/start: 0 ms
                uri == "/record/start" && session.method == Method.POST -> serveRecordStart()
                // LONGEST WAIT /record/poll: 0 ms
                uri == "/record/poll" && session.method == Method.GET -> serveRecordPoll()
                // LONGEST WAIT /record/stop: 0 ms
                uri == "/record/stop" && session.method == Method.POST -> serveRecordStop()
                // LONGEST WAIT /screenshot: 3000 ms — the screenshot pacer holds for up to its 3 s circuit
                uri == "/screenshot" && session.method == Method.GET -> serveScreenshot()
                // LONGEST WAIT /display: 0 ms
                uri == "/display" && session.method == Method.GET -> serveDisplay()
                // LONGEST WAIT /tree: 0 ms
                uri == "/tree" && session.method == Method.GET -> serveTree(session)
                // LONGEST WAIT /probe: 0 ms — the app's probe answers through a ContentResolver call with no bound; the host ends it
                uri == "/probe" && session.method == Method.GET -> serveProbe(session)
                // LONGEST WAIT /probe/tree: 0 ms — as /probe
                uri == "/probe/tree" && session.method == Method.GET -> serveProbeTree(session)
                // LONGEST WAIT /tap-at-norm-coord: from the request — times × interval and each touch, then a 0.5 s idle wait
                uri == "/tap-at-norm-coord" && session.method == Method.POST ->
                    serveTapAtNormCoord(session)
                // LONGEST WAIT /swipe-at-norm-coord: 500 ms — a 0.5 s idle wait
                uri == "/swipe-at-norm-coord" && session.method == Method.POST ->
                    serveSwipeAtNormCoord(session)
                // LONGEST WAIT /pinch-at-norm-coord: from the request — durationMs + panMs and 0.4 s around them (PREROLL_MS, HOLD_MS), then a 0.5 s idle wait
                uri == "/pinch-at-norm-coord" && session.method == Method.POST ->
                    servePinch(session)
                // LONGEST WAIT /swipe-once: 500 ms — a 0.5 s idle wait
                uri == "/swipe-once" && session.method == Method.POST ->
                    serveSwipeOnce(session)
                // LONGEST WAIT /press-key: 500 ms — a 0.5 s idle wait
                uri == "/press-key" && session.method == Method.POST ->
                    servePressKey(session)
                // LONGEST WAIT /back: 11500 ms — the wait for a still screen (BACK_BEFORE_MS) and the back settle (BACK_SETTLE_MS), each with one look past it
                uri == "/back" && session.method == Method.POST -> serveBack()
                // LONGEST WAIT /hide-keyboard: 6500 ms — a 0.5 s idle wait, KEYBOARD_GONE_MS and one look past it
                uri == "/hide-keyboard" && session.method == Method.POST -> serveHideKeyboard()
                // LONGEST WAIT /set-orientation: 7800 ms — a 0.8 s idle wait, ROTATION_ARRIVES_MS and one look past it
                uri == "/set-orientation" && session.method == Method.POST ->
                    serveSetOrientation(session)
                // LONGEST WAIT /tap-by-id: 8075 ms — the 1.5 s poll, one lookup's 2 s idle wait, 75 ms, a 0.5 s idle wait and one look past the poll
                uri == "/tap-by-id" && session.method == Method.POST -> serveTapById(session)
                // LONGEST WAIT /double-tap-at-norm-coord: 650 ms — 150 ms between the taps and a 0.5 s idle wait
                uri == "/double-tap-at-norm-coord" && session.method == Method.POST ->
                    serveDoubleTapAtNormCoord(session)
                // LONGEST WAIT /long-press-at-norm-coord: from the request — durationMs, then a 0.5 s idle wait
                uri == "/long-press-at-norm-coord" && session.method == Method.POST ->
                    serveLongPressAtNormCoord(session)
                // LONGEST WAIT /input-text: from the request — budgetMs
                uri == "/input-text" && session.method == Method.POST -> serveInputText(session)
                // LONGEST WAIT /clear-text: 19000 ms — FOCUS_SETTLE_MS, a 0.5 s idle wait, the delete keys and TEXT_LAND_MS, and one look past each of its two polls
                uri == "/clear-text" && session.method == Method.POST -> serveClearText(session)
                // LONGEST WAIT /windows: 0 ms
                uri == "/windows" && session.method == Method.GET -> serveWindows()
                // LONGEST WAIT /foreground: 7500 ms — a 0.5 s idle wait, FOREGROUND_ARRIVES_MS and one look past it
                uri == "/foreground" && session.method == Method.POST -> serveForeground(session)
                // LONGEST WAIT /find-text-by-ocr: 8000 ms — the screenshot pacer (3 s) and the recogniser latch (5 s)
                uri == "/find-text-by-ocr" && session.method == Method.POST ->
                    serveFindTextByOcr(session)
                // LONGEST WAIT /system-popups: 0 ms
                uri == "/system-popups" && session.method == Method.GET -> serveSystemPopups(session)
                // LONGEST WAIT /system-popup-action: 500 ms — a 0.5 s idle wait
                uri == "/system-popup-action" && session.method == Method.POST ->
                    serveSystemPopupAction(session)
                // LONGEST WAIT /webview-eval: 11000 ms — the WebView bridge's 5 s connect and 6 s read
                uri == "/webview-eval" && session.method == Method.POST ->
                    serveWebViewEvalProxy(session)
                // LONGEST WAIT /session/open: 500 ms — a 0.5 s idle wait
                uri == "/session/open" && session.method == Method.POST ->
                    serveSessionOpen(session)
                // LONGEST WAIT /session/close: 0 ms
                uri == "/session/close" && session.method == Method.POST ->
                    serveSessionClose(session)
                // LONGEST WAIT /session/close-all: 0 ms
                uri == "/session/close-all" && session.method == Method.POST ->
                    serveSessionCloseAll()
                // LONGEST WAIT /session/list: 0 ms
                uri == "/session/list" && session.method == Method.POST ->
                    serveSessionList()
                // LONGEST WAIT /session/renew-activation: 500 ms — a 0.5 s idle wait
                uri == "/session/renew-activation" && session.method == Method.POST ->
                    serveSessionRenewActivation(session)
                // LONGEST WAIT /session/launch-app: 500 ms — a 0.5 s idle wait
                uri == "/session/launch-app" && session.method == Method.POST ->
                    serveSessionAppLifecycle(session, terminate = false)
                // LONGEST WAIT /session/terminate-app: 500 ms — a 0.5 s idle wait
                uri == "/session/terminate-app" && session.method == Method.POST ->
                    serveSessionAppLifecycle(session, terminate = true)
                // LONGEST WAIT /session/relaunch-app: 500 ms — a 0.5 s idle wait
                uri == "/session/relaunch-app" && session.method == Method.POST ->
                    serveSessionRelaunchApp(session)
                else -> serveNotImplemented(uri, session.method.name)
            }
        } catch (e: Throwable) {
            val body = RunnerWire.internalErrorBody(
                e.message ?: e.javaClass.simpleName,
                e.javaClass.name,
            )
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "application/json", body)
        }
        android.util.Log.i(
            RouteLog.TAG,
            RouteLog.line(
                uri,
                response.status.requestStatus,
                android.os.SystemClock.elapsedRealtime() - arrived,
                RouteLog.current.get(),
            ),
        )
        RouteLog.current.remove()
        return response
    }

    /// A route's clock, kept where the request's log line can read it.
    private fun routeClock(path: String): RouteClock =
        RouteClock(RouteLimits.of(path)).also { RouteLog.current.set(it) }

    private fun serveHealth(): Response {
        val body = RunnerWire.healthBody(SmixRunner.VERSION)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    // ---- recorder (v2.10-C2) ------------------------------------------
    // /record/start begins capture; /record/poll drains accumulated IRAction
    // JSON (streaming); /record/stop drains the remainder and deactivates.

    private fun serveRecordStart(): Response {
        // OK MEANS: bookkeeping — the recorder started buffering. It
        // watches events; it does not act on the device.
        RecordBuffer.start()
        return newFixedLengthResponse(Response.Status.OK, "application/json", "{\"ok\":true}")
    }

    private fun serveRecordPoll(): Response = recordEventsResponse(RecordBuffer.poll())

    // OK MEANS: bookkeeping — the buffer was drained and the recorder
    // stopped. Above the function because it has no body to put a line
    // inside.
    private fun serveRecordStop(): Response = recordEventsResponse(RecordBuffer.stop())

    private fun recordEventsResponse(actions: List<String>): Response {
        // Each action is already an IRAction JSON object string.
        val body = "{\"events\":[" + actions.joinToString(",") + "]}"
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    /**
     * What the in-process probe says, or that there is not one.
     *
     * The probe lives in the app under test, not here — it can read the
     * semantics tree because it is in that process, and this runner cannot.
     * So this asks across a content provider and reports the answer
     * verbatim, including its absence.
     *
     * Absence is an answer, not an error: most apps will not carry the
     * probe and everything works without it. What must never happen is the
     * two being confused. "The screen is busy" and "nobody told me
     * anything" want different waits, and one value for both is how 250 ms
     * of guessing became indistinguishable from being told.
     *
     * The app is named by the caller when the caller has a name to give.
     * A flow always does. The CLI does not, and for as long as that meant
     * "no probe", `smix tree` answered from the accessibility projection
     * while a flow on the same screen answered from the semantics tree.
     * So when nobody said, the window holding the focus says — see
     * [ProbeTarget], which is the only place that inference is made.
     */
    private fun serveProbe(session: NanoHTTPD.IHTTPSession): Response {
        val app = probeTarget(session).orEmpty()
        if (app.isEmpty()) {
            return newFixedLengthResponse(
                Response.Status.OK, "application/json",
                """{"present":false,"why":"no app was named and no application window holds the focus; ask /probe?app=<applicationId>"}""",
            )
        }
        val body = try {
            val ctx = InstrumentationRegistry.getInstrumentation().context
            val hello = ProbeCall.call(ctx, app, "hello")
            if (hello == null) {
                """{"present":false,"why":"$app has no smix probe in this build"}"""
            } else {
                // Milliseconds the semantics tree has looked unchanged, or
                // -1 for "never looked". Not a boolean: the caller decides
                // how still is still enough, and a boolean would bake that
                // threshold in here where nobody can see it.
                val idle = ProbeCall.call(ctx, app, "idle")
                val quiet = idle?.getLong("quietMs") ?: -1L
                // absent from a probe older than the field: null, not -1
                val late = idle?.takeIf { it.containsKey("sampleLateMs") }?.getLong("sampleLateMs")
                val pending = idle?.takeIf { it.containsKey("framesPending") }?.getBoolean("framesPending")
                val roots = hello.getInt("roots", 0)
                val version = hello.getString("version") ?: "?"
                RunnerWire.probePresentBody(app, version, roots, quiet, hello.getString("library"), late, pending)
            }
        } catch (e: IllegalArgumentException) {
            // Resolving an authority nothing declares throws rather than
            // returning null, and this is the ORDINARY case: almost no app
            // carries the probe. Reading it back as an exception would make
            // the normal state look like a fault, which is how a caller
            // learns to ignore the field.
            """{"present":false,"why":"$app declares no smix probe — it is not in this build"}"""
        } catch (e: SecurityException) {
            // There and refusing. A different problem from not being there,
            // and the caller can act on the difference: the probe answers
            // adb, the host app, and smix's own instrumentation.
            """{"present":false,"why":"$app has a smix probe and it refused this caller"}"""
        } catch (e: Exception) {
            """{"present":false,"why":"asking $app.smixprobe raised ${e.javaClass.simpleName}"}"""
        }
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    /** The probe's semantics tree, verbatim. */
    private fun serveProbeTree(session: NanoHTTPD.IHTTPSession): Response {
        val app = probeTarget(session).orEmpty()
        if (app.isEmpty()) {
            return newFixedLengthResponse(
                Response.Status.OK, "application/json", "[]",
            )
        }
        val body = try {
            val ctx = InstrumentationRegistry.getInstrumentation().context
            val b = ProbeCall.call(ctx, app, "tree")
            if (b == null) "[]" else {
                // The screen's size travels with the tree because the
                // consumer normalises against the root's rectangle, and the
                // probe's roots cover only what Compose occupies.
                //
                // Roles are named on the way past: the probe reports the
                // class and Compose's own role, and the table that turns
                // either into smix's word for it lives here, next to the
                // accessibility path that needs the same table.
                //
                // The screen is this runner's, not the probe's. The probe
                // measures from inside the app, and a tap is turned back
                // into pixels here; one number for both ends is the only
                // way a normalised coordinate means the same thing at each.
                val (w, h) = displaySize()
                ProbeRoles.fill(
                    """{"screen":[$w,$h],""" +
                        """"roots":${b.getString("tree") ?: "[]"}}""",
                )
            }
        } catch (_: Exception) {
            // Separate from /probe on purpose: that route reports WHETHER
            // there is a probe and why not, and this one only carries the
            // tree. Folding them would make asking "is it there" cost a
            // whole screen's worth of JSON.
            "[]"
        }
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveTree(session: IHTTPSession): Response {
        // Walk UiAutomation.windows directly instead of
        // device.dumpWindowHierarchy. The XML dump only emits one window
        // hierarchy at a time and on some Android versions skips the
        // foreground app window (returning only status_bar — observed on
        // API 33 emulator with android-runner test instrumentation in
        // separate process from the app). Direct AccessibilityNodeInfo
        // walk via UiAutomation iterates all attached windows and
        // surfaces Compose testTag via
        // AccessibilityNodeInfo.viewIdResourceName.
        //
        // Snapshot-freshness headers, parity with the iOS runner:
        // `X-Tree-Snapshot-Refresh-Count` is a monotonic count of
        // successful /tree serves since runner boot,
        // `X-Tree-Snapshot-Wall-Ms` is this walk's end-to-end wall.
        // The pair lets callers detect snapshot pipeline stalls /
        // slowdown across a batch without any wire-body change.
        val walkStart = System.currentTimeMillis()
        val automation = instrumentation.uiAutomation
        val hollow = session.parameters["hollow"]?.firstOrNull()?.takeIf { it.isNotEmpty() }
        val ids = hollow?.let(::appWindowIds).orEmpty()
        val askedMs = System.currentTimeMillis() - walkStart
        val root = TreeBuilder.fromWindows(automation, displaySize(), hollow, ids)
        val wallMs = System.currentTimeMillis() - walkStart
        val refreshCount = treeServeCounter.incrementAndGet()
        val resp = newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            root.toString(),
        )
        resp.addHeader("X-Tree-Snapshot-Refresh-Count", refreshCount.toString())
        resp.addHeader("X-Tree-Snapshot-Wall-Ms", wallMs.toString())
        // the part of the wall spent asking the app's probe which windows are its own
        resp.addHeader("X-Tree-App-Windows-Ms", askedMs.toString())
        return resp
    }

    /// Every attached window, and whether its root could be read.
    ///
    /// `/tree` answers "what is on screen"; this answers "why is
    /// something not". A consumer reported the tree carrying only the
    /// SystemUI windows and not their app's, and neither of us could
    /// tell from here whether their app's window was absent from the
    /// list or present and unreadable — different problems, identical
    /// symptom, and no way to look.
    /// The ids of `app`'s windows, from its probe; empty when there is no
    /// probe or it is older than the question, and its windows are then
    /// read the ordinary way.
    private fun appWindowIds(app: String): Set<Int> = try {
        ProbeCall.call(InstrumentationRegistry.getInstrumentation().context, app, "windows")
            ?.getIntArray("windowIds")?.toSet().orEmpty()
    } catch (_: Exception) {
        emptySet()
    }

    private fun serveWindows(): Response {
        val rows = JSONArray()
        val windows = instrumentation.uiAutomation.windows
        for ((i, w) in windows.withIndex()) {
            val root = w.root
            rows.put(
                TreeWire.windowRowJson(
                    index = i,
                    type = w.type,
                    layer = w.layer,
                    active = w.isActive,
                    focused = w.isFocused,
                    rootReadable = root != null,
                    packageName = root?.packageName?.toString(),
                    kind = WindowRules.kindOf(w.type),
                ),
            )
            root?.recycle()
        }
        val body = TreeWire.windowsJson(rows).toString()
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    /// What a touch at `(px, py)` is about to be delivered to, read from
    /// the tree the caller aimed from; see [HitReader].
    private fun hitChainAt(session: IHTTPSession, reader: HitChain.Reader, px: Int, py: Int): HitChain.Reading {
        val app = if (reader == HitChain.Reader.SEMANTICS) probeTarget(session) else null
        val (w, h) = displaySize()
        return HitReader(instrumentation).read(reader, app, HitChain.Box(0, 0, w, h), px, py)
    }

    /// The display's size, in the pixels a touch is injected in.
    ///
    /// The one place it is read. The tree's root, the probe tree's
    /// `screen`, and every normalised coordinate a caller sends are all
    /// this number: the host divides a node's centre by the root and this
    /// runner multiplies the share back by the display, so any second
    /// source for either end moves every selector tap by the ratio
    /// between them. It had two — the root was the union of readable
    /// windows, and the probe's `screen` was measured in the app's
    /// process — and a dialog's confirm button was pressed 800 pixels
    /// below the dialog.
    private fun displaySize(): Pair<Int, Int> = device.displayWidth to device.displayHeight

    /// The display's size (from [displaySize], the one place it is read)
    /// and its density — how many of the pixels every reader here reports
    /// make one device-independent point. The density is the display's
    /// own, override included, which is what the app is laid out in.
    private fun serveDisplay(): Response {
        val (w, h) = displaySize()
        val density = instrumentation.targetContext.resources.displayMetrics.density
        val body = RunnerWire.displayBody(w, h, density)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveTapAtNormCoord(session: IHTTPSession): Response {
        // OK MEANS: injected — `UiDevice.click` is `clickNoSync`, which
        // is `injectEventSync` for every touch and refuses a point off the
        // display. Whether the app did anything is the next assertion.
        val payload = readBodyString(session)
        val req = RunnerWire.decodeNormCoord(payload)
        val (w, h) = displaySize()
        val px = RunnerWire.normToPixel(req.nx, w)
        val py = RunnerWire.normToPixel(req.ny, h)
        // Before the touch: a confirm that lands takes its dialog away.
        val chain = hitChainAt(session, RunnerWire.decodeAimedBy(payload), px, py)
        AimCheck.decode(payload)?.let { t -> AimCheck.gone(t, chain)?.let { t to it } }?.let { (t, saw) ->
            return newFixedLengthResponse(Response.Status.CONFLICT, "application/json", AimCheck.goneBody(saw, t))
        }
        val ok = TapBurst.decode(payload).touch(
            { device.click(px, py) }, { device.swipe(px, py, px, py, RunnerWire.longPressSteps(it)) }, Thread::sleep,
        )
        // Give the dispatched IO event time to render before /tree probes
        // observe the post-tap UI state.
        device.waitForIdle(500)
        val body = RunnerWire.tapAtNormCoordBody(ok, w, h, px, py, chain)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveSwipeAtNormCoord(session: IHTTPSession): Response {
        // OK MEANS: injected — `UiDevice.swipe` hands the gesture to
        // `InteractionController.swipe`; the boolean is whether the
        // pointer events went in.
        val req = RunnerWire.decodeSwipeAtNormCoord(readBodyString(session))
        val (w, h) = displaySize()
        val q = RunnerWire.SwipeQuad(
            RunnerWire.normToPixel(req.fromNx, w),
            RunnerWire.normToPixel(req.fromNy, h),
            RunnerWire.normToPixel(req.toNx, w),
            RunnerWire.normToPixel(req.toNy, h),
        )
        // 50 steps ≈ 500ms — enough to register as fling/scroll, not so
        // fast it's interpreted as a tap.
        val ok = device.swipe(q.x1, q.y1, q.x2, q.y2, 50)
        device.waitForIdle(500)
        val body = RunnerWire.swipeAtNormCoordBody(ok, q)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun servePinch(session: IHTTPSession): Response {
        // OK MEANS: injected — every motion event of both fingers went in; whether the app zoomed is the caller's next assertion.
        val gesture: PinchGesture
        val plan: PinchGesture.Plan
        try {
            gesture = PinchGesture.decode(readBodyString(session))
            val (w, h) = displaySize()
            val slop = android.view.ViewConfiguration.get(instrumentation.targetContext).scaledTouchSlop
            plan = gesture.plan(w, h, slop.toFloat())
        } catch (e: IllegalArgumentException) {
            return errorJson(Response.Status.BAD_REQUEST, "bad_request", e.message ?: "bad pinch request")
        }
        val ok = injectPinch(gesture.timeline(plan))
        device.waitForIdle(500)
        return newFixedLengthResponse(Response.Status.OK, "application/json", RunnerWire.pinchBody(ok, plan))
    }

    /// Put a two-finger timeline in as touchscreen motion events, each at
    /// its own time after the first. `UiDevice` has no multi-finger
    /// gesture at a point, so the events are built here. Stops at the
    /// first event that does not go in, after lifting what is down, so a
    /// failed gesture does not leave a finger on the screen.
    private fun injectPinch(events: List<PinchGesture.Event>): Boolean {
        val automation = instrumentation.uiAutomation
        val down = android.os.SystemClock.uptimeMillis()
        val props = Array(2) { i ->
            android.view.MotionEvent.PointerProperties().apply {
                id = i
                toolType = android.view.MotionEvent.TOOL_TYPE_FINGER
            }
        }
        var last: PinchGesture.Event? = null
        for (e in events) {
            val at = down + e.atMs
            val wait = at - android.os.SystemClock.uptimeMillis()
            if (wait > 0) android.os.SystemClock.sleep(wait)
            if (!automation.injectInputEvent(motionEvent(down, at, e, props), true)) {
                last?.let { liftAfterFailure(down, it, props) }
                return false
            }
            last = e
        }
        return true
    }

    private fun motionEvent(
        down: Long,
        at: Long,
        e: PinchGesture.Event,
        props: Array<android.view.MotionEvent.PointerProperties>,
    ): android.view.MotionEvent {
        val action = when (e.action) {
            PinchGesture.Action.DOWN -> android.view.MotionEvent.ACTION_DOWN
            PinchGesture.Action.POINTER_DOWN -> android.view.MotionEvent.ACTION_POINTER_DOWN or
                (1 shl android.view.MotionEvent.ACTION_POINTER_INDEX_SHIFT)
            PinchGesture.Action.MOVE -> android.view.MotionEvent.ACTION_MOVE
            PinchGesture.Action.POINTER_UP -> android.view.MotionEvent.ACTION_POINTER_UP or
                (1 shl android.view.MotionEvent.ACTION_POINTER_INDEX_SHIFT)
            PinchGesture.Action.UP -> android.view.MotionEvent.ACTION_UP
        }
        val coords = e.fingers.map { p ->
            android.view.MotionEvent.PointerCoords().apply {
                x = p.x
                y = p.y
                pressure = 1f
                size = 1f
            }
        }.toTypedArray()
        return android.view.MotionEvent.obtain(
            down, at, action, coords.size, props.copyOfRange(0, coords.size), coords,
            0, 0, 1f, 1f, 0, 0, android.view.InputDevice.SOURCE_TOUCHSCREEN, 0,
        )
    }

    private fun liftAfterFailure(
        down: Long,
        last: PinchGesture.Event,
        props: Array<android.view.MotionEvent.PointerProperties>,
    ) {
        val now = android.os.SystemClock.uptimeMillis()
        val automation = instrumentation.uiAutomation
        if (last.fingers.size == 2 && last.action != PinchGesture.Action.POINTER_UP) {
            automation.injectInputEvent(
                motionEvent(down, now, PinchGesture.Event(0, PinchGesture.Action.POINTER_UP, last.fingers), props),
                true,
            )
        }
        if (last.action != PinchGesture.Action.UP) {
            automation.injectInputEvent(
                motionEvent(down, now, PinchGesture.Event(0, PinchGesture.Action.UP, listOf(last.fingers[0])), props),
                true,
            )
        }
    }

    private fun serveSwipeOnce(session: IHTTPSession): Response {
        // OK MEANS: injected — same call and same meaning as
        // /swipe-at-norm-coord. The scroll loop driving this re-reads the
        // tree afterwards, which is where "did anything move" is answered.
        val direction = RunnerWire.decodeSwipeOnce(readBodyString(session))
        val q = displaySize().let { (w, h) -> RunnerWire.swipeOnceCoords(direction, w, h) }
            ?: return errorJson(
                Response.Status.BAD_REQUEST,
                "bad_direction",
                "expected one of up/down/left/right, got '$direction'",
            )
        val ok = device.swipe(q.x1, q.y1, q.x2, q.y2, 50)
        device.waitForIdle(500)
        val body = RunnerWire.swipeOnceBody(ok, direction, q)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun servePressKey(session: IHTTPSession): Response {
        // OK MEANS: injected — `pressKeyCode` is `sendKeys` →
        // `injectEventSync`. This route used to discard that boolean and
        // answer `status: ok` to everything, so a key that never went in
        // and a key that did read identically to the host.
        val key = RunnerWire.decodePressKey(readBodyString(session))
        val code = KeyMap.androidKeyCode(key) ?: return errorJson(
            Response.Status.BAD_REQUEST,
            "unknown_key",
            "no Android KeyEvent mapping for '$key'",
        )
        val injected = device.pressKeyCode(code)
        device.waitForIdle(500)
        val body = RunnerWire.pressKeyBody(injected, key, code)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveBack(): Response {
        // OK MEANS: outcome — the screen that was on before the key is
        // not the screen that is on after it. `UiDevice.pressBack()`'s
        // own boolean answers a third question (its bytecode is
        // `sendKeyAndWaitForEvent(KEYCODE_BACK, 0, TYPE_WINDOW_CONTENT_CHANGED, 1000)`,
        // so the status bar's clock can carry it and a navigation that
        // lands late cannot), which is why the key goes in by plain
        // injection here and the answer is read afterwards. The
        // injection result is reported as `injected`, never as `ok`.
        val clock = routeClock("/back")
        val still = BeforeSettle(BACK_STILL_MS)
        val before = clock.stage("before") {
            awaitStillScreen(still, clock.budget(BACK_BEFORE_MS))
        }
        val deepBefore = clock.stage("deepBefore") {
            var last = readScreen(deep = true)
            var steady: ScreenReading? = null
            for (attempt in 1..DEEP_STEADY_TRIES) {
                val next = readScreen(deep = true)
                steady = steadyDeepReading(last, next)
                if (steady != null) break
                last = next
            }
            steady
        }
        val injected = injectBackKey()
        val settle = BackSettle(before)
        val started = android.os.SystemClock.elapsedRealtime()
        var looks = 0
        val verdict = if (!injected) {
            BackSettle.Verdict.NotInjected
        } else {
            // A stage the route's limit left no time for looked at
            // nothing, and "the screen never changed" needs a look.
            val bounded = clock.stage("settle") {
                awaitBackVerdict(settle, clock.budget(BACK_SETTLE_MS)) { looks += 1 }
            } ?: BackSettle.Verdict.CouldNotSee
            if (bounded == BackSettle.Verdict.GaveUp) {
                clock.stage("deep") { deepVerdict(deepBefore, readScreen(deep = true)) }
                    ?: BackSettle.Verdict.CouldNotSee
            } else {
                bounded
            }
        }
        val took = android.os.SystemClock.elapsedRealtime() - started
        val body = RunnerWire.backBody(
            ok = verdict.ok,
            settledBy = verdict.settledBy,
            saw = "${settle.saw()} deepBefore=${deepBefore?.brief() ?: "<unsteady>"} " +
                "beforeLooks=${still.looks} looks=$looks tookMs=$took " +
                "budgetMs=$BACK_SETTLE_MS ${clock.stagesText()}",
            injected = injected,
        )
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    /// Look until the verdict lands or the budget is spent.
    ///
    /// 50ms polls over 2s, the same cadence and budget the iOS runner
    /// settled on for the same question — its notes record that looking
    /// less often (250ms) was measured and was worse.
    private fun awaitBackVerdict(settle: BackSettle, budgetMs: Long, looked: () -> Unit): BackSettle.Verdict {
        val deadline = android.os.SystemClock.elapsedRealtime() + budgetMs
        while (true) {
            Thread.sleep(BACK_POLL_MS)
            looked()
            val started = android.os.SystemClock.elapsedRealtime()
            settle.observeStartedAt(readScreen(), started, deadline)?.let { return it }
        }
    }

    /// Look until the screen has held still for `BACK_STILL_MS`, or
    /// `null` when the budget is spent first.
    private fun awaitStillScreen(still: BeforeSettle, budgetMs: Long): ScreenReading? {
        val deadline = android.os.SystemClock.elapsedRealtime() + budgetMs
        while (true) {
            val started = android.os.SystemClock.elapsedRealtime()
            still.observe(readScreen(), started)?.let { return it }
            if (started >= deadline) return null
            Thread.sleep(BACK_POLL_MS)
        }
    }

    /// One look at everything on screen.
    ///
    /// No window is chosen. Picking one — active, then focused, then
    /// topmost — was the first version, and measured on emulator-5554
    /// the pick moved between two looks 50ms apart: three runs of the
    /// same script called one back key `packageLeft`, `gaveUp` and
    /// `couldNotSee`. Hashing the whole set removes the choice, and
    /// `currentPackageName` is read once, as a reading rather than as a
    /// decision about which window matters.
    private fun readScreen(deep: Boolean = false): Reading {
        // The whole-tree reading is for seeing inside the app's windows;
        // windows arriving and leaving are the bounded reading's to see.
        // Leaving the status bar out keeps a notification landing during
        // the wait from reading as the key's doing.
        val windows = instrumentation.uiAutomation.windows.filter {
            !deep || it.type == AccessibilityWindowInfo.TYPE_APPLICATION
        }
        if (windows.isEmpty()) return Reading.Unreadable
        // A window whose root will not read stays in the reading, with
        // the parts that did not read left empty. Dropping it is what
        // N1 was: `uiAutomation.windows` lists a window whose root
        // comes back null, so a look that missed the app's window and a
        // look taken after the app's window left produced the same
        // reading, and `/back` answered "the screen changed" on a
        // screen the app had never left. The walk next door
        // (`readWindowRows`) has always kept the row and left the
        // package null; this one now does the same.
        //
        // By id, because a window's id outlives the layer order that a
        // transition shuffles.
        val readings = windows.sortedBy { it.id }.map { window ->
            val application = window.type == AccessibilityWindowInfo.TYPE_APPLICATION
            val root = window.root
            if (root == null) {
                WindowReading(window.id, pkg = null, structure = null, application = application)
            } else {
                try {
                    // The package is read from the root already in
                    // hand. `UiDevice.currentPackageName` would name
                    // the one in front, and it waits for the screen to
                    // go idle to do it — ten seconds, measured, on a
                    // screen with a label ticking five times a second,
                    // which is the very screen this route has to answer
                    // for.
                    WindowReading(
                        window.id,
                        pkg = root.packageName?.toString(),
                        structure = if (deep) {
                            structureHash(root, DEEP_WINDOW_BUDGET, Int.MAX_VALUE, fresh = true)
                        } else {
                            structureHash(root, STRUCTURE_WINDOW_BUDGET, STRUCTURE_DEPTH_CAP, fresh = false)
                        },
                        application = application,
                    )
                } finally {
                    root.recycle()
                }
            }
        }
        return Reading.Screen(ScreenReading(readings))
    }

    /// Put the back key in, and nothing else.
    ///
    /// Not `UiDevice.pressBack()`, whose answer is about an
    /// accessibility event rather than about the screen, and not
    /// `UiDevice.pressKeyCode` either: both call `waitForIdle()` first,
    /// which on a screen that is animating or ticking waits out its
    /// whole ten-second budget before the key goes anywhere. Measured:
    /// one `/back` on the fixture's blocked screen took 30s, three idle
    /// waits deep, while its own settle budget is 2s.
    private fun injectBackKey(): Boolean {
        val now = android.os.SystemClock.uptimeMillis()
        val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK, 0)
        val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BACK, 0)
        val automation = instrumentation.uiAutomation
        return automation.injectInputEvent(down, true) && automation.injectInputEvent(up, true)
    }

    /// A hash of which nodes are under `root` — not of what they say.
    ///
    /// Text is left out on purpose: a clock, a spinner or a countdown
    /// changes text on every frame while nothing has gone back, and
    /// that is precisely the shape `pressBack()`'s boolean gets wrong.
    /// Bounded because this runs every 50ms: four levels and a shared
    /// budget of 120 nodes across every window are enough to tell two
    /// screens apart and cheap enough to ask for forty times in a row.
    ///
    /// `fresh` refreshes every node before reading it. The accessibility
    /// cache hands back children as they were when last fetched, and
    /// refreshing the root does not reach them: measured on the fixture's
    /// nav screen, a whole-tree walk took 12ms and read the detail that a
    /// back had just closed as still there.
    private fun structureHash(root: AccessibilityNodeInfo, budget: Int, depthCap: Int, fresh: Boolean): Int {
        var hash = 17
        var seen = 0
        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (seen >= budget) return
            seen += 1
            if (fresh && !node.refresh()) {
                // gone between the parent's read and this one
                hash = hash * 31 + 1
                return
            }
            val name = node.viewIdResourceName ?: node.className?.toString() ?: ""
            hash = hash * 31 + name.hashCode()
            hash = hash * 31 + node.childCount
            if (depth >= depthCap) return
            for (i in 0 until node.childCount) {
                if (seen >= budget) return
                val child = node.getChild(i) ?: continue
                try {
                    walk(child, depth + 1)
                } finally {
                    child.recycle()
                }
            }
        }
        walk(root, 0)
        return hash
    }

    private fun serveHideKeyboard(): Response {
        // OK MEANS: outcome — the input-method window is gone, read
        // from the window list after the key rather than taken from the
        // key press's own boolean (6.5).
        // There is no first-class UiAutomator2 hide-keyboard, and the
        // closest thing is back. Back closes a keyboard when one is up
        // and closes whatever is in front when none is — so the comment
        // that used to sit here, claiming "no harm if no keyboard is
        // up", described an intent the code did not carry out. Measured
        // on emulator-5554: with nothing focused this answered ok:true
        // and sent the fixture app to the launcher.
        //
        // That matters beyond the surprise. iOS needs the dismissal (the
        // keyboard covers the button the next step taps) and maestro
        // treats it as a no-op when there is no keyboard, so a flow
        // written once for both platforms cannot be asked to know
        // whether a keyboard is up before saying "put it away". The
        // no-op is what makes the verb portable.
        //
        // An input-method window is the evidence, and it is the same
        // window list /windows already serves.
        if (!keyboardIsUp()) {
            val body = RunnerWire.hideKeyboardBody(true)
            return newFixedLengthResponse(Response.Status.OK, "application/json", body)
        }
        // `pressBack()` returns whether the key event was injected, and
        // a consumer measured it answering false while the keyboard
        // came down — `{"ok":false}` with the IME gone from the window
        // list one call later. Its boolean is about the injection, not
        // about the outcome, and this route was reporting the wrong one
        // of those.
        //
        // The outcome has its own evidence, and it is the same evidence
        // the no-op decision above already uses. Ask it afterwards.
        val clock = routeClock("/hide-keyboard")
        device.pressBack()
        device.waitForIdle(500)
        val gone = clock.stage("keyboard-gone") { awaitKeyboardGone(clock.budget(KEYBOARD_GONE_MS)) } == true
        val body = RunnerWire.hideKeyboardBody(gone)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    /// How many characters the field holds once the clear has had time
    /// to reach it, watched rather than sampled.
    ///
    /// A Compose field publishes to its accessibility node
    /// asynchronously — the reason `awaitChunk` watches a fill. One read
    /// straight after `ACTION_SET_TEXT` caught `compose_input` still
    /// holding all fifteen characters it was being emptied of, and the
    /// fill that followed was refused as "the clear did not happen"
    /// (the behaviour gate's A10, emulator-5554, 2026-09-25). Returns as
    /// soon as the field reads empty; otherwise what it held when the
    /// budget ran out.
    private fun awaitEmptied(focusPx: IntArray?, budgetMs: Long): Int {
        // The budget is the whole wait. Each look used to wait for focus on
        // a budget of its own — FOCUS_SETTLE_MS, 6 s since 2026-09-23 —
        // so with no field in focus this 2-second wait took 6, and a clear
        // on a screen with nothing to clear took 12 s to say so (measured
        // 2026-09-25; the e2e that asks gives it 10).
        return Poll.until(budgetMs, 50, { left -> focusedTextLength(focusPx, left) }, { it == 0 })
    }

    /// How many characters the focused field holds, or -1 when no
    /// focused editable node can be found to ask.
    ///
    /// -1 is not zero: "the field is empty" and "I could not find the
    /// field" are different answers, and only one of them means a clear
    /// worked.
    private fun focusedTextLength(focusPx: IntArray?, budgetMs: Long): Int {
        val node = awaitEditableFocus(budgetMs, focusPx) ?: return -1
        return try {
            FieldText.held(node.text, node.isShowingHintText).length
        } finally {
            node.recycle()
        }
    }

    /// Wait for the input-method window to leave, up to a budget.
    ///
    /// The dismissal is animated, so the window outlives the key press
    /// by a frame or two; a single look straight afterwards can catch
    /// it still there and call a working dismissal a failure. Same
    /// shape as the text read-back next door — one instant cannot
    /// answer a question about a transition.
    private fun awaitKeyboardGone(budgetMs: Long): Boolean {
        return !Poll.until(budgetMs, 50, { keyboardIsUp() }, { !it })
    }

    /// Is an input-method window on screen?
    ///
    /// `TYPE_INPUT_METHOD` is what the IME's own window reports, so this
    /// asks the same source /windows does rather than guessing from
    /// focus — a focused text field with the keyboard dismissed is an
    /// ordinary state, and it is exactly the one that used to send back
    /// through to the app.
    private fun keyboardIsUp(): Boolean =
        readWindowRows().any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }

    /// The window stack, as the decision on the other side reads it.
    ///
    /// One walk for the three questions that ask about windows — is the
    /// keyboard up, what is on the screen, and who is over the app in a
    /// failure. They disagreed about nothing so far because two of them
    /// did not exist yet.
    private fun readWindowRows(): List<WindowRules.Row> =
        instrumentation.uiAutomation.windows.map { w ->
            val root = w.root
            val pkg = root?.packageName?.toString()
            root?.recycle()
            WindowRules.Row(w.type, pkg, w.layer, w.isActive || w.isFocused)
        }

    /// Which package the caller is driving, when the caller said.
    ///
    /// The `App-Bundle-Id` header every smix request already carries,
    /// or `?app=<pkg>` for a caller holding nothing but curl.
    ///
    /// **Nothing is guessed when neither is given.** The first version
    /// of this fell back to "the focused application window", and the
    /// permission dialog — the very thing this route exists to report —
    /// is a focused application window, so it was taken for the app
    /// under test and reported as nothing at all. A caller who did not
    /// say which app they are driving gets every window that took the
    /// focus and carries buttons, their own dialogs included; the doc
    /// says so.
    private fun appUnderTest(session: IHTTPSession): String? =
        session.headers["app-bundle-id"]?.takeIf { it.isNotEmpty() }
            ?: session.parameters["app"]?.firstOrNull()?.takeIf { it.isNotEmpty() }

    /// Which package the probe routes ask, including when nobody said.
    ///
    /// Separate from [appUnderTest] on purpose, and the difference is
    /// what each is for. That one feeds `/system-popups`, where a guess
    /// makes a dialog classify itself as the app it covers and the
    /// route reports nothing — so it never guesses. Asking the wrong
    /// package for a probe only answers `present:false`, the same
    /// answer as asking about nothing, so here the focused window is
    /// allowed to speak. The rule itself is in [ProbeTarget].
    private fun probeTarget(session: IHTTPSession): String? =
        ProbeTarget.pick(::readWindowRows, appUnderTest(session))

    private fun serveSetOrientation(session: IHTTPSession): Response {
        // OK MEANS: outcome — the display is left in the rotation that
        // was asked for, read back from `displayRotation`. It used to
        // answer `status: ok` unconditionally, including for the
        // upside-down case it emulates with two rotations and cannot
        // promise on every device.
        val orientation = RunnerWire.decodeSetOrientation(readBodyString(session))
        when (orientation) {
            "portrait" -> device.setOrientationNatural()
            "landscapeLeft" -> device.setOrientationLeft()
            "landscapeRight" -> device.setOrientationRight()
            "portraitUpsideDown" ->
                // UiDevice has no upside-down call. The emulation that
                // used to be here — natural, then two left rotations —
                // lands at rotation 1 rather than 2 (measured,
                // emulator-5554), and nothing checked, so this verb has
                // been quietly doing something else and saying it
                // worked. The settings route gets there.
                RunnerWire.rotateUpsideDownCommands().forEach { runShellCommand(it) }
            else -> return errorJson(
                Response.Status.BAD_REQUEST,
                "bad_orientation",
                "expected portrait | landscapeLeft | landscapeRight | portraitUpsideDown, got '$orientation'",
            )
        }
        val clock = routeClock("/set-orientation")
        device.waitForIdle(800)
        // A rotation is a transition, and one look cannot answer a
        // question about a transition — the settings route in
        // particular takes a moment longer than the window manager's
        // own calls, and a single read right after it caught the
        // display still at its old value.
        val want = RunnerWire.rotationFor(orientation)
        val rotation = clock.stage("rotation") {
            Poll.until(clock.budget(ROTATION_ARRIVES_MS), 50, { device.displayRotation }, { it == want })
        } ?: -1
        val body = RunnerWire.setOrientationBody(
            RunnerWire.rotationMatches(orientation, rotation),
            orientation,
            rotation,
        )
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveTapById(session: IHTTPSession): Response {
        // OK MEANS: action-performed — an accessibility ACTION_CLICK
        // reported that it ran, or, on the touch fallback, a node
        // matching the id was found and clicked. `UiObject2.click()`
        // returns nothing, so on that path `ok` says a gesture was made
        // on a node that existed, and `path` says which of the two it
        // was. Neither is a claim about the app having reacted.
        val id = RunnerWire.decodeTapById(readBodyString(session))
        // NanoHTTPD lowercases header names.
        val targetPackage = session.headers["app-bundle-id"]
        // Prefer AccessibilityNodeInfo.performAction(ACTION_CLICK) over
        // UiObject2.click() because Compose Button onClick fires
        // reliably through the a11y action path even when a sibling
        // AndroidView (MapView / PlayerView / PreviewView) GestureDetector
        // would intercept a synthesized touch event. Fall back to
        // UiObject2.click() for non-Compose Views without ACTION_CLICK
        // in their actions list.
        //
        // Poll up to 1500ms for both findNodeByViewId AND ACTION_CLICK
        // presence. Compose recompose vs. a11y semantics commit is
        // asynchronous (NavHost transitions especially); a single-shot
        // probe loses the race intermittently. Polling makes /tap-by-id
        // auto-await the a11y tree settling without leaking timing
        // details to the caller. Latency cost for present targets is
        // small (first iter hits in <100ms); for genuinely missing
        // targets it adds up to 1500ms (still correct, just slower error).
        val clock = routeClock("/tap-by-id")
        val pollDeadlineMs = System.currentTimeMillis() + clock.budget(1500)
        var clicked = false
        var path = "none"
        var sawNode = false
        var sawActionClick = false
        var matchedSpelling: String? = null
        var sawStrictHit = false
        while (System.currentTimeMillis() < pollDeadlineMs && !clicked) {
            val (targetNode, matched) = findNodeByViewId(id, targetPackage)
            if (matched != null) {
                matchedSpelling = matched
                sawStrictHit = true
            }
            if (targetNode != null) {
                sawNode = true
                val actions = targetNode.actionList
                val hasClickAction =
                    actions.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }
                if (hasClickAction) {
                    sawActionClick = true
                    clicked = targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) path = "a11y"
                }
                targetNode.recycle()
                if (clicked) break
            }
            if (!clicked) Thread.sleep(75)
        }
        // Touch fallback only after a11y poll fully exhausted — `path:"touch"`
        // therefore means "node never grew an ACTION_CLICK within 1.5s, or
        // never appeared in the a11y tree at all".
        if (!clicked) {
            val candidates = listOf(
                By.res(Regex(".*:id/${Regex.escape(id)}$").toPattern()),
                By.res(id),
            )
            for (sel in candidates) {
                val obj = device.findObject(sel)
                if (obj != null) {
                    obj.click()
                    clicked = true
                    path = "touch"
                    break
                }
            }
        }
        device.waitForIdle(500)
        val body = RunnerWire.tapByIdBody(clicked, id, path, sawNode, sawActionClick)
        val response = newFixedLengthResponse(Response.Status.OK, "application/json", body)
        // A header, not a body field. v1.0.23 settled the same question
        // for the tree-snapshot counters: the body of this route has a
        // Rust-side parser reading its five fields, so adding one is a
        // wire-contract change while adding a header is not.
        //
        // "miss" is distinct from "walk": the walk answering is a
        // different fact from nothing answering at all.
        val kind = if (!sawNode && !sawStrictHit) {
            "miss"
        } else {
            RunnerWire.viewIdMatchKind(matchedSpelling, id, targetPackage)
        }
        response.addHeader("X-View-Id-Match", kind)
        return response
    }

    /// Find first node matching `viewIdResourceName`, returning it
    /// alongside the spelling that hit (null when the manual walk
    /// answered instead). Candidates come from
    /// `RunnerWire.viewIdCandidates`: the bare id, the app under test
    /// qualified by the App-Bundle-Id header, then the runner's own
    /// test package. This comment used to name `com.example.app` among
    /// them — that placeholder was removed from the candidate list, and
    /// saying otherwise here outlived the code by a day.
    /// Caller owns the returned node and MUST
    /// recycle.
    ///
    /// Manual AccessibilityNodeInfo recycling during tree traversal
    /// poisons the framework cache and causes subsequent /tree queries
    /// to return stale state, breaking yaml flows where an optional
    /// tap (find-fail) precedes a real tap. Strict
    /// findAccessibilityNodeInfosByViewId handles recycling internally
    /// — let the framework own that lifecycle.
    ///
    /// We walk `uiAutomation.windows` (multi-window) instead of
    /// `rootInActiveWindow` (single-window). Mirrors `/tree` builder and
    /// UiObject2 lookup, which both walk all windows. Compose app
    /// content isn't always the focused window (e.g. when a SystemUI
    /// IME / overlay grabs focus); single-window lookup silently misses
    /// the app content and forces touch-fallback for every tap. Multi-
    /// window matches what the caller sees in /tree, which is the
    /// consistent surface they expect to address by id.
    private fun findNodeByViewId(
        shortId: String,
        targetPackage: String?,
    ): Pair<AccessibilityNodeInfo?, String?> {
        val candidates = RunnerWire.viewIdCandidates(shortId, targetPackage)
        for (window in instrumentation.uiAutomation.windows) {
            val root = window.root ?: continue
            for (cand in candidates) {
                val hits = root.findAccessibilityNodeInfosByViewId(cand)
                if (hits.isNotEmpty()) {
                    val node = hits[0]
                    hits.drop(1).forEach { it.recycle() }
                    // The spelling travels with the node. Without it the
                    // caller cannot tell a strict hit from the walk
                    // below, and those two returning the same node is
                    // exactly how a placeholder package survived here.
                    return node to cand
                }
            }
        }
        // Manual walk fallback. Reality observed: Compose
        // `testTagsAsResourceId = true` emits viewIdResourceName on
        // every Composable Button and /tree dumps surface the ids
        // correctly, but `findAccessibilityNodeInfosByViewId` returns
        // empty for them (likely because Compose synthesizes virtual
        // resource ids that aren't registered with the framework's
        // resource lookup table — a structural Compose ↔
        // AccessibilityFramework gap; not fixable by FLAG_REPORT_VIEW_IDS
        // or window iteration alone).
        //
        // The walk doesn't recycle traversed children (manual recycle
        // during tree traversal evicts framework cache entries that
        // subsequent ops need, breaking optional-tap patterns). Memory
        // cost per query is small — one walk per /tap-by-id — and the
        // leak only matters under sustained pressure. Accept it for
        // chained NavHost reliability.
        //
        // Flush pending accessibility events before re-reading windows.
        // UiAutomator2 caches windows[].root snapshots; after a NavHost
        // transition the visual UI advances (screenshots confirm the
        // next screen is rendered) but `automation.windows[].root` still
        // reports the previous screen unless we wait for the
        // accessibility event stream to settle. `waitForIdle(idleTime,
        // globalTimeout)` blocks until no accessibility events arrived
        // for `idleTime` ms or `globalTimeout` elapses. 500ms idle /
        // 2000ms cap is generous for Compose recompose + NavHost
        // transition without leaking into pathological slow runs.
        instrumentation.uiAutomation.waitForIdle(500, 2000)
        for (window in instrumentation.uiAutomation.windows) {
            val root = window.root ?: continue
            root.refresh()
            val found = walkFindByViewIdNoRecycle(root, shortId)
            if (found != null) return found to null
        }
        return null to null
    }

    /// Recursive walk matching `viewIdResourceName` short suffix
    /// (post-`:id/` strip). Does NOT recycle child nodes — see the
    /// findNodeByViewId comment for the cache-poisoning constraint that
    /// forces this. Returns a fresh `obtain()` copy on match so the
    /// caller's `.recycle()` is independent of the framework's window-
    /// owned tree.
    private fun walkFindByViewIdNoRecycle(
        node: AccessibilityNodeInfo,
        shortId: String,
    ): AccessibilityNodeInfo? {
        // Per-node refresh re-syncs each AccessibilityNodeInfo with
        // current framework state. Coarse root.refresh() (caller side)
        // only refreshes the top node; cached descendants keep stale
        // state for chained NavHost transitions. Refreshing each
        // descendant before reading viewIdResourceName forces the
        // framework to honor any pending semantics updates from the most
        // recent Compose recompose.
        node.refresh()
        val vid = node.viewIdResourceName
        if (vid != null && vid.isNotEmpty()) {
            val short = vid.substringAfter(":id/", vid)
            if (short == shortId) {
                return AccessibilityNodeInfo.obtain(node)
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = walkFindByViewIdNoRecycle(child, shortId)
            if (found != null) return found
            // Intentional: no `child.recycle()` — see comment above.
        }
        return null
    }

    private fun serveDoubleTapAtNormCoord(session: IHTTPSession): Response {
        // OK MEANS: injected — both taps went in. One of two landing is
        // not a double tap, so the answer is the conjunction.
        val payload = readBodyString(session)
        val req = RunnerWire.decodeNormCoord(payload)
        val (w, h) = displaySize()
        val px = RunnerWire.normToPixel(req.nx, w)
        val py = RunnerWire.normToPixel(req.ny, h)
        val chain = hitChainAt(session, RunnerWire.decodeAimedBy(payload), px, py)
        val first = device.click(px, py)
        // Standard double-tap inter-tap window — 150ms is below most
        // systems' DOUBLE_TAP_TIMEOUT (300ms) so events register as a
        // pair, not as two separate taps.
        Thread.sleep(150)
        val second = device.click(px, py)
        device.waitForIdle(500)
        val body = RunnerWire.doubleTapBody(first && second, px, py, chain)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveLongPressAtNormCoord(session: IHTTPSession): Response {
        // OK MEANS: injected — a long press is a swipe that does not
        // travel, so this is `InteractionController.swipe`'s answer.
        val payload = readBodyString(session)
        val req = RunnerWire.decodeLongPressAtNormCoord(payload)
        val (w, h) = displaySize()
        val px = RunnerWire.normToPixel(req.nx, w)
        val py = RunnerWire.normToPixel(req.ny, h)
        val chain = hitChainAt(session, RunnerWire.decodeAimedBy(payload), px, py)
        val injected = device.swipe(px, py, px, py, RunnerWire.longPressSteps(req.durationMs))
        device.waitForIdle(500)
        val body = RunnerWire.longPressBody(injected, px, py, req.durationMs, chain)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveInputText(session: IHTTPSession): Response {
        // OK MEANS: outcome — the characters are in the field, read
        // back from the node afterwards (v6.4). `input text` cannot
        // report a miss, so the node saying so is the only evidence
        // there is.
        val req = RunnerWire.decodeInputText(readBodyString(session))
        val started = android.os.SystemClock.elapsedRealtime()
        val text = req.text
        val focusPx = focusRectPx(req.focusIn)
        // `adb shell input text` types into whichever field is focused,
        // and says nothing about whether one was. Its exit code means
        // "the key events were dispatched", not "the characters landed"
        // — so this used to answer OK unconditionally, and a consumer
        // reported the first named fill on a screen typing nothing while
        // reporting success. Reproduced on emulator-5554 with the
        // fixture: `smix fill` said "17 chars", the field held none.
        //
        // The clear handler next door has always done this properly:
        // find the focused editable node, act on it, report what
        // happened. This is that, for the other half of the same job.
        //
        // Waiting for the focus rather than sampling once: the caller
        // taps to focus immediately before, and an IME that has not
        // finished coming up has no focused editable node yet. That gap
        // is the whole defect — the second fill on a screen always
        // worked because by then the keyboard was already open.
        val focused = awaitEditableFocus(FOCUS_SETTLE_MS, focusPx)
        if (focused == null) {
            // Who is over the app, in the failure that it caused.
            //
            // A consumer lost six seconds and a screenshot to this: their
            // keyboard had opened its own promotion dialog over the field,
            // and every word of this message was about focus. The walk was
            // already being done next door for `keyboardIsUp`.
            val rows = readWindowRows()
            val above = WindowRules.windowStackSentence(rows, appUnderTest(session))
            return newFixedLengthResponse(
                Response.Status.INTERNAL_ERROR,
                "application/json",
                RunnerWire.noFocusedFieldEnvelope(
                    "input-text: no editable field had focus after " +
                        "${FOCUS_SETTLE_MS}ms. `input text` types into the focused " +
                        "field and there was none, so the characters would have " +
                        "gone nowhere while this reported success." +
                        if (above.isEmpty()) "" else " $above",
                    rows,
                ),
            )
        }

        val before = FieldText.held(focused.text, focused.isShowingHintText)
        // The node says whether it masks. Nothing here guesses it from
        // the text: `aaaa` is four of the same character and is not a
        // mask, and a guess would quietly stop checking content for
        // anyone whose password repeats one.
        val masked = focused.isPassword
        // Name the field. "The focused field holds 0" was a claim about
        // a node the reader could not identify, and the node it meant
        // was not always the one they had asked for — a walk over every
        // window returns the first focused editable node, and while an
        // IME is up that need not be the app's.
        val whichField = focused.viewIdResourceName
            ?: focused.className?.toString()
            ?: "an unnamed node"
        val fieldPackage = focused.packageName?.toString()
        if (!TextEntry.typable(text)) {
            val value = TextEntry.target(before, text, masked)
                ?: return errorJson(Response.Status.INTERNAL_ERROR, "text_not_typable", TextEntry.maskedRefusal(whichField))
            val took = TextEntry.set(focused, value)
            val held = awaitChunk(focused, before, text, masked, TEXT_LAND_MS).text.also { focused.recycle() }
            val landed = took && RunnerWire.textLanded(before, held, text, masked)
            return newFixedLengthResponse(Response.Status.OK, "application/json", RunnerWire.inputTextBody(landed, text, before, held, masked))
        }
        // In chunks, each read back before the next. One `input text` of
        // 120 characters came back short under load (2 of 10 whole at load
        // 11–15) while 64 held every time; a chunk read back on its own can
        // also tell a dropped tail, which typing its missing part repairs,
        // from anything else, which typing more cannot.
        val result = ChunkedInput.typeInChunks(
            text,
            before,
            masked,
            ChunkedInput.INPUT_CHUNK_POINTS,
            ChunkedInput.INPUT_CHUNK_RETYPES,
            // A chunk is not begun unless its read-back fits in what is left:
            // past the budget there is then only the chunk's `input text`
            // and the one look its poll may begin at the end, which the
            // host's table allows for.
            { req.budgetMs?.let { android.os.SystemClock.elapsedRealtime() - started + TEXT_LAND_MS > it } ?: false },
        ) { erase, sent, base, chunk ->
            // No `waitForIdle` here: `awaitChunk` polls until the chunk has
            // landed, and the idle wait spent 0.5–0.9 s of every chunk
            // (measured, 2026-09-27) before a read that did not need it.
            if (erase > 0) runShellCommand(RunnerWire.deleteKeysCommand(erase))
            runShellCommand(RunnerWire.inputTextCommand(sent))
            awaitChunk(focused, base, chunk, masked, TEXT_LAND_MS)
        }
        focused.recycle()
        val done = when (result) {
            is ChunkedInput.ChunkedResult.Failed -> return chunkDidNotLand(
                text, whichField, masked, before, result.held, result.chunk, result.of, result.retries,
                ChunkedInput.focusNow(fieldPackage, focusedWindowPackage()),
            )
            is ChunkedInput.ChunkedResult.OutOfTime -> return errorJson(
                Response.Status.INTERNAL_ERROR,
                "text_budget_spent",
                "input-text: the host's budget of ${req.budgetMs}ms for ${text.length} " +
                    "character(s) had too little left to type and read back chunk " +
                    "${result.chunk + 1} of ${result.of} (${TEXT_LAND_MS}ms); " +
                    "$whichField went from ${before.length} to ${result.held.length} " +
                    "character(s). Nothing more was typed, so the field holds what landed.",
            )
            is ChunkedInput.ChunkedResult.FieldLeft -> return if (result.allSent) {
                newFixedLengthResponse(
                    Response.Status.OK,
                    "application/json",
                    ChunkedInput.leftWithEverythingBody(text, before, result.held, masked, result.of),
                )
            } else {
                errorJson(Response.Status.INTERNAL_ERROR, "field_left", ChunkedInput.stoppedMessage(result, text, whichField, masked))
            }
            is ChunkedInput.ChunkedResult.FocusLeft -> return errorJson(
                Response.Status.INTERNAL_ERROR,
                "focus_left",
                ChunkedInput.stoppedMessage(result, text, whichField, masked) +
                    ChunkedInput.focusNow(fieldPackage, focusedWindowPackage()),
            )
            is ChunkedInput.ChunkedResult.Done -> result
        }
        val after = done.held
        val landed = RunnerWire.textLanded(before, after, text, masked)
        val body = RunnerWire.inputTextBody(landed, text, before, after, masked, done.chunks, done.retyped)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    /// The focused editable node, waited for rather than sampled.
    ///
    /// Returns null when none appears in time. The caller recycles.
    ///
    /// `refresh()` before reading `isEditable`, for the reason
    /// `nodeToJson` already gives: a node handed out by the framework
    /// carries the fields it had when it was fetched, and a Compose
    /// field that has just taken focus is exactly the case where those
    /// are out of date. Without it this reported "no editable field had
    /// focus" for two seconds about a field the tree showed as focused
    /// in the same instant — the two reads disagreed because only one
    /// of them was current.
    /// Convert the caller's tap point to screen pixels, or null when
    /// they did not name a field.
    /// The named element's box in screen pixels, or null when the
    /// caller named no element.
    private fun focusRectPx(r: RunnerWire.NormRect?): IntArray? =
        r?.let {
            val (w, h) = displaySize()
            val l = RunnerWire.normToPixel(it.nx, w)
            val t = RunnerWire.normToPixel(it.ny, h)
            intArrayOf(
                l,
                t,
                l + RunnerWire.normToPixel(it.nw, w),
                t + RunnerWire.normToPixel(it.nh, h),
            )
        }

    private fun awaitEditableFocus(
        budgetMs: Long,
        focusPx: IntArray? = null,
    ): AccessibilityNodeInfo? {
        return Poll.until(
            budgetMs,
            50,
            { focusedTextNode(focusPx) },
            { it != null },
            pause = { device.waitForIdle(100); Thread.sleep(it) },
        )
    }

    /// Whatever holds focus and can be typed into, asked two ways.
    ///
    /// `findFocus(FOCUS_INPUT)` is the framework's answer and it is the
    /// right question to ask first. It is not the only place the answer
    /// lives: Compose keeps focus in its own semantics layer, and on a
    /// freshly composed screen it comes back empty about a field the
    /// tree reports as focused in the same instant — with the IME
    /// window already up. Measured on emulator-5554, twice, on the
    /// first fill after the activity starts. That "first fill on a
    /// screen" is exactly the shape a consumer reported.
    ///
    /// So when the direct query has nothing, walk for it. The walk is
    /// what the tree route already does, and it costs a traversal only
    /// on the path where the cheap answer failed.
    private fun focusedTextNode(focusPx: IntArray?): AccessibilityNodeInfo? {
        val focused = anyFocusedTextNode() ?: return null
        if (focusPx == null || holdsFocusPoint(focused, focusPx)) {
            return focused
        }
        // The focused field is not the one under the tap. That is the
        // defect this point exists for — unless nothing typeable is
        // under the tap at all, which is the ordinary case of naming a
        // container: a consumer's fields carry only a contentDescription
        // on the wrapping layout, so the point is the layout's centre
        // and the field that takes focus sits somewhere inside it.
        // Refusing there broke every fill in that app.
        val aimedAt = editableUnder(focusPx)
        if (aimedAt == null) {
            return focused
        }
        aimedAt.recycle()
        focused.recycle()
        return null
    }

    /// Whatever holds focus and can be typed into, without asking where.
    private fun anyFocusedTextNode(): AccessibilityNodeInfo? {
        val direct = instrumentation.uiAutomation.findFocus(
            AccessibilityNodeInfo.FOCUS_INPUT,
        )
        if (direct != null) {
            direct.refresh()
            // The framework's answer is taken only when the node agrees
            // with it. On Compose, after Enter in one field and a tap on
            // the next, `findFocus` kept returning the first field for
            // seconds — a node that, refreshed, reports `isFocused=false`
            // — while the tree showed the second one focused (measured
            // 2026-09-25, four refusals in five runs of a consumer's
            // sign-in sequence). The walk below asks every node itself.
            if (direct.isFocused && (direct.isEditable || direct.canTakeText())) return direct
            direct.recycle()
        }
        for (window in instrumentation.uiAutomation.windows) {
            val root = window.root ?: continue
            searchFocusedTextNode(root, null)?.let { return it }
        }
        return null
    }

    /// A typeable node whose own bounds hold this point, focused or not.
    ///
    /// The point only decides anything when there is one: if the caller
    /// aimed at a field and a *different* field has focus, the tap has
    /// not landed yet and typing now would go to the wrong place. If
    /// they aimed at something that is not itself typeable, the point
    /// has nothing to say and whatever took focus is the answer.
    private fun editableUnder(focusPx: IntArray): AccessibilityNodeInfo? {
        for (window in instrumentation.uiAutomation.windows) {
            val root = window.root ?: continue
            searchEditableUnder(root, focusPx)?.let { return it }
        }
        return null
    }

    private fun searchEditableUnder(
        node: AccessibilityNodeInfo,
        focusPx: IntArray,
    ): AccessibilityNodeInfo? {
        node.refresh()
        if ((node.isEditable || node.canTakeText()) && holdsFocusPoint(node, focusPx)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val hit = searchEditableUnder(child, focusPx)
            if (hit != null) return hit
            child.recycle()
        }
        return null
    }

    /// Is this the field the caller named?
    ///
    /// Focus in Compose does not move synchronously with the tap that
    /// moves it, so "some editable node has focus" is true before the
    /// tap as well as after — and a fill naming one field was measured
    /// clearing and typing into another. With a tap point the answer is
    /// no until focus reaches the field containing it; without one,
    /// every focused field qualifies, which is what a fill with no
    /// selector means.
    private fun holdsFocusPoint(
        node: AccessibilityNodeInfo,
        focusPx: IntArray?,
    ): Boolean {
        if (focusPx == null) return true
        val r = android.graphics.Rect()
        node.getBoundsInScreen(r)
        return RunnerWire.focusAccepts(r.left, r.top, r.right, r.bottom, focusPx)
    }

    /// Depth-first for a focused node that accepts text.
    private fun searchFocusedTextNode(
        node: AccessibilityNodeInfo,
        focusPx: IntArray?,
    ): AccessibilityNodeInfo? {
        node.refresh()
        if (node.isFocused && (node.isEditable || node.canTakeText()) &&
            holdsFocusPoint(node, focusPx)
        ) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val hit = searchFocusedTextNode(child, focusPx)
            if (hit != null) return hit
            child.recycle()
        }
        return null
    }

    /// Does this node accept text, whatever it says about being editable?
    ///
    /// `isEditable` is a claim a toolkit has to make about itself, and
    /// a Compose text field does not always make it. What is not
    /// optional is the action: a node that will take `ACTION_SET_TEXT`
    /// is a node characters can be put into, and that is the thing
    /// being asked about.
    private fun AccessibilityNodeInfo.canTakeText(): Boolean =
        actionList.any { it.id == AccessibilityNodeInfo.ACTION_SET_TEXT }

    /// Read the field until the chunk has landed whole, or the budget
    /// runs out, and return what it held last.
    private fun awaitChunk(
        node: AccessibilityNodeInfo,
        base: String,
        chunk: String,
        masked: Boolean,
        budgetMs: Long,
    ): ChunkedInput.Reading {
        return Poll.until(
            budgetMs,
            50,
            {
                // `refresh` answers whether the node is still in the hierarchy.
                // Ignoring that read a field that had left as holding nothing.
                if (!node.refresh()) {
                    ChunkedInput.Reading(base, present = false, focused = false)
                } else {
                    ChunkedInput.Reading(
                        FieldText.held(node.text, node.isShowingHintText),
                        present = true,
                        focused = node.isFocused,
                    )
                }
            },
            {
                !it.present ||
                    ChunkedInput.chunkOutcome(base, it.text, chunk, masked) == ChunkedInput.ChunkOutcome.Landed
            },
        )
    }

    /// The failure for a chunk that did not land: which chunk, how many
    /// times its tail was typed again, and what the field held.
    private fun chunkDidNotLand(
        text: String,
        whichField: String,
        masked: Boolean,
        before: String,
        now: String,
        index: Int,
        of: Int,
        retries: Int,
        focusNow: String,
    ): Response = errorJson(
        Response.Status.INTERNAL_ERROR,
        "text_did_not_land",
        if (masked) {
            "input-text: chunk ${index + 1} of $of did not land in the masked field " +
                "$whichField after $retries retype(s) of its missing tail: it went " +
                "from ${before.length} to ${now.length} characters for ${text.length} " +
                "typed. A masked node reports its length and never its characters, " +
                "so the length is the only evidence there is, and it does not add up."
        } else {
            "input-text: typed \"$text\" into $whichField in $of chunk(s); chunk " +
                "${index + 1} did not land after $retries retype(s) of its missing " +
                "tail. The field held \"$before\" and holds \"$now\". Characters are " +
                "missing from the middle, or there are characters this step did not " +
                "type — neither is repaired by typing more."
        } + focusNow,
    )

    /// The package of the window holding the input focus, when the
    /// runner can read it.
    private fun focusedWindowPackage(): String? {
        val window = instrumentation.uiAutomation.windows.firstOrNull { it.isFocused } ?: return null
        val root = window.root ?: return null
        return try {
            root.packageName?.toString()
        } finally {
            root.recycle()
        }
    }

    /// Empty the focused field in one request.
    ///
    /// The host used to do this by posting `/press-key DELETE` fifty
    /// times — fifty sequential round trips over the adb forward, on
    /// every fill once fill started clearing first. Worse than slow:
    /// fifty deletes do not empty a field holding more than fifty
    /// characters, so the text that followed landed after the
    /// remainder and the caller was told it had replaced the value.
    ///
    /// `ACTION_SET_TEXT` is exact and length-independent, and it is
    /// what `UiObject2.clear()` uses underneath. When no focused
    /// editable node answers — a field the accessibility tree cannot
    /// address is exactly the case the key-event path exists for —
    /// fall back to delete keys, still in one shell exec, and say
    /// which path ran so the caller knows whether the answer is exact.
    private fun serveClearText(session: IHTTPSession): Response {
        // OK MEANS: outcome — the field is empty afterwards, and
        // `method` says by which of the two routes it was emptied.
        // The clear that precedes a fill needs the same target as the
        // typing. Without it a fill naming one field empties whichever
        // field happened to hold focus — measured on emulator-5554,
        // compose_password went from ten characters to none while the
        // caller had named compose_input.
        val focusPx = focusRectPx(RunnerWire.decodeClearText(readBodyString(session)))
        val clock = routeClock("/clear-text")
        val focused = clock.stage("focus") { awaitEditableFocus(clock.budget(FOCUS_SETTLE_MS), focusPx) }
        if (focused != null && focused.isEditable &&
            FieldText.held(focused.text, focused.isShowingHintText).isEmpty()
        ) {
            // Nothing to clear, and clearing anyway costs the text that
            // follows: setting a field's text makes the keyboard restart
            // its input session, and while a keyboard that has just started
            // (Gboard on API 36, measured 2026-09-29) does that, the first
            // key events typed after it are lost — `cold1-first` arrived as
            // `old1-first` in 2 of 5 fills that cleared first, 0 of 5 that
            // did not.
            focused.recycle()
            return clearTextAnswer(clock, focusPx, "already-empty", 0)
        }
        if (focused != null && focused.isEditable) {
            val args = android.os.Bundle()
            args.putCharSequence(
                android.view.accessibility.AccessibilityNodeInfo
                    .ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                "",
            )
            val ok = clock.stage("set-text") {
                focused.performAction(
                    android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT,
                    args,
                )
            } == true
            focused.recycle()
            if (ok) return clearTextAnswer(clock, focusPx, "set-text", 0)
        } else {
            focused?.recycle()
        }
        // Sent in batches, each only while the route's limit lasts: one
        // shell command of sixty-four keys has no bound on a loaded
        // emulator, and it was the one stage this route could not stop.
        var deletes = 0
        while (deletes < FALLBACK_DELETE_COUNT) {
            val batch = minOf(DELETE_BATCH, FALLBACK_DELETE_COUNT - deletes)
            clock.stage("delete-keys") { runShellCommand(RunnerWire.deleteKeysCommand(batch)) } ?: break
            deletes += batch
        }
        return clearTextAnswer(clock, focusPx, "key-events", deletes)
    }

    /// Settle, read the field back, and answer — or say where the route's
    /// limit ran out. Fifty-odd delete keys with nothing checking what they
    /// did was once the whole of the key-event path's evidence; the field
    /// itself can say.
    private fun clearTextAnswer(clock: RouteClock, focusPx: IntArray?, method: String, deletes: Int): Response {
        clock.stage("idle") { device.waitForIdle(minOf(500L, clock.leftMs())) }
        val held = clock.stage("readback") { awaitEmptied(focusPx, clock.budget(TEXT_LAND_MS)) }
        val body = if (held == null) {
            RunnerWire.clearTextSpentBody(false, method, deletes, clock.saw())
        } else {
            RunnerWire.clearTextBody(held == 0, method, deletes, held)
        }
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveForeground(session: IHTTPSession): Response {
        // OK MEANS: outcome — the named package owns the foreground
        // afterwards, read from `currentPackageName`. Running an `am
        // start` and reporting success is a different claim: the
        // activity can fail to start, and the shell says so on a channel
        // this route was not reading.
        // smix wire (HttpRunnerClient.foreground) sends {bundleId} per
        // iOS swift /foreground convention. Mirror that shape.
        val bundleId = RunnerWire.decodeForeground(readBodyString(session))
        // Android equivalent: `am start --activity-single-top -n
        // pkg/.MainActivity`. This brings the app to foreground without
        // launching a new instance (matches the iOS XCUIDevice activate
        // semantic).
        val clock = routeClock("/foreground")
        runShellCommand(RunnerWire.foregroundCommand(bundleId, entryPoint(bundleId)))
        device.waitForIdle(500)
        // An activity takes a moment to come forward, so this is a
        // deadline on something that has usually already happened.
        val current = clock.stage("arrives") {
            Poll.until(clock.budget(FOREGROUND_ARRIVES_MS), 50, { device.currentPackageName }, { it == bundleId })
        }
        val body = RunnerWire.foregroundBody(
            current == bundleId,
            bundleId,
            "foreground=${current ?: "<none>"}",
        )
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    // ---- /session/* ------------------------------------------------------
    //
    // Minimal session surface so the Kotlin SDK (driving through the FFI
    // session API → smix-runner-client) can talk to the Android runner.
    // Sessions on iOS cache an XCUIApplication binding to kill the
    // activation storm; Android has no per-request activation to
    // suppress, so a session here is pure bookkeeping: an id ↔ bundleId
    // binding that the lifecycle routes (launch/terminate/relaunch) act
    // on via the same shell-exec pathway /foreground uses.

    private val sessions = SessionTable()

    private fun serveSessionOpen(session: IHTTPSession): Response {
        // OK MEANS: bookkeeping — a session id was bound to a bundle id. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        val req = RunnerWire.decodeSessionOpen(readBodyString(session))
        if (req.bundleId.isEmpty()) {
            return sessionError(
                Response.Status.BAD_REQUEST,
                RunnerWire.sessionBadRequestBody("bundleId must be a non-empty string"),
            )
        }
        // iOS semantics: activate:true → foreground the target once,
        // synchronously, before returning; activatedOnce mirrors it.
        if (req.activate) {
            runShellCommand(RunnerWire.foregroundCommand(req.bundleId, entryPoint(req.bundleId)))
            device.waitForIdle(500)
        }
        val entry = sessions.open(req.bundleId, activated = req.activate)
        val body = RunnerWire.sessionOpenBody(entry.sessionId, req.activate, entry.openedAtMs)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveSessionClose(session: IHTTPSession): Response {
        // OK MEANS: bookkeeping — a session id was released. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        val sid = RunnerWire.decodeSessionId(readBodyString(session))
        if (sid.isEmpty()) {
            return sessionError(
                Response.Status.BAD_REQUEST,
                RunnerWire.sessionBadRequestBody("sessionId must be a non-empty string"),
            )
        }
        sessions.close(sid)
        return newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            RunnerWire.sessionCloseBody(),
        )
    }

    private fun serveSessionCloseAll(): Response {
        // OK MEANS: bookkeeping — every session id was released. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        val closed = sessions.closeAll()
        return newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            RunnerWire.sessionCloseAllBody(closed),
        )
    }

    private fun serveSessionList(): Response {
        // OK MEANS: bookkeeping — the runner's own session table was read. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        return newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            RunnerWire.sessionListBody(sessions.list()),
        )
    }

    private fun serveSessionRenewActivation(session: IHTTPSession): Response {
        // OK MEANS: bookkeeping — a session id was refreshed. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        val sid = RunnerWire.decodeSessionId(readBodyString(session))
        if (sid.isEmpty()) {
            return sessionError(
                Response.Status.BAD_REQUEST,
                RunnerWire.sessionBadRequestBody("sessionId must be a non-empty string"),
            )
        }
        val entry = sessions.renewActivation(sid) ?: return sessionError(
            Response.Status.NOT_FOUND,
            RunnerWire.sessionNotFoundBody("unknown session id"),
        )
        runShellCommand(RunnerWire.foregroundCommand(entry.bundleId, entryPoint(entry.bundleId)))
        device.waitForIdle(500)
        return newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            RunnerWire.sessionRenewBody(activated = true),
        )
    }

    private fun serveSessionAppLifecycle(session: IHTTPSession, terminate: Boolean): Response {
        // OK MEANS: bookkeeping — a session id was resolved and the lifecycle command handed to the shell. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        // Body carries sessionId (+ args/env/waitFor*Ms, accepted and
        // ignored — XCUITest launch-injection has no `am` equivalent).
        val sid = RunnerWire.decodeSessionId(readBodyString(session))
        if (sid.isEmpty()) {
            return sessionError(
                Response.Status.BAD_REQUEST,
                RunnerWire.sessionBadRequestBody("sessionId must be a non-empty string"),
            )
        }
        val entry = sessions.get(sid) ?: return sessionError(
            Response.Status.NOT_FOUND,
            RunnerWire.sessionNotFoundBody("unknown session id"),
        )
        val start = System.currentTimeMillis()
        val cmd = if (terminate) {
            RunnerWire.terminateAppCommand(entry.bundleId)
        } else {
            RunnerWire.foregroundCommand(entry.bundleId, entryPoint(entry.bundleId))
        }
        runShellCommand(cmd)
        device.waitForIdle(500)
        val wallMs = System.currentTimeMillis() - start
        return newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            RunnerWire.sessionLifecycleBody(true, wallMs),
        )
    }

    private fun serveSessionRelaunchApp(session: IHTTPSession): Response {
        // OK MEANS: bookkeeping — a session id was resolved and the app relaunched through the shell path /foreground uses. Sessions on Android are
        // record-keeping: there is no per-request activation here for
        // them to succeed or fail at.
        val sid = RunnerWire.decodeSessionId(readBodyString(session))
        if (sid.isEmpty()) {
            return sessionError(
                Response.Status.BAD_REQUEST,
                RunnerWire.sessionBadRequestBody("sessionId must be a non-empty string"),
            )
        }
        val entry = sessions.get(sid) ?: return sessionError(
            Response.Status.NOT_FOUND,
            RunnerWire.sessionNotFoundBody("unknown session id"),
        )
        val start = System.currentTimeMillis()
        runShellCommand(RunnerWire.terminateAppCommand(entry.bundleId))
        runShellCommand(RunnerWire.foregroundCommand(entry.bundleId, entryPoint(entry.bundleId)))
        device.waitForIdle(500)
        val wallMs = System.currentTimeMillis() - start
        return newFixedLengthResponse(
            Response.Status.OK,
            "application/json",
            RunnerWire.sessionRelaunchBody(true, wallMs),
        )
    }

    private fun sessionError(status: Response.Status, body: String): Response =
        newFixedLengthResponse(status, "application/json", body)

    /// The activity `am start -n` should name for this package.
    ///
    /// Every launch route used to hard-code `.MainActivity`, which is
    /// what a scaffolded app is called and what almost nothing else is:
    /// an AOSP app, or one whose entry point was renamed, simply did
    /// not start, and the response said nothing about why. The package
    /// manager already knows, and the runner has a Context to ask with.
    ///
    /// Returns null when it cannot answer, which
    /// `RunnerWire.foregroundCommand` reads as "use the old
    /// convention" — no device that worked before is worse off.
    private fun entryPoint(bundleId: String): String? {
        val pm = instrumentation.targetContext.packageManager
        val component = pm.getLaunchIntentForPackage(bundleId)?.component ?: return null
        val name = component.className
        return if (name.startsWith("$bundleId.")) {
            name.removePrefix(bundleId)
        } else {
            name
        }
    }

    private fun runShellCommand(cmd: String) {
        val pfd = instrumentation.uiAutomation.executeShellCommand(cmd)
        try {
            // Drained so the command has finished before this returns, and
            // stopped if it has not within its limit.
            ShellLimit.drain(cmd, java.io.FileInputStream(pfd.fileDescriptor)) { pfd.close() }
        } finally {
            pfd.close()
        }
    }

    private fun serveFindTextByOcr(session: IHTTPSession): Response {
        // OK MEANS: reading — this answers where some text is and acts
        // on nothing. `found` carries the answer; there is no act to
        // succeed or fail.
        // locales + recognition_level are iOS-specific Apple Vision args;
        // the ML Kit Latin script package handles ASCII/Latin universally
        // so they are accepted but ignored here. Dedicated CJK packages
        // can be added when the app under test needs them
        // (text-recognition-chinese / japanese / korean / devanagari
        // packages add ~10MB each).
        val target = RunnerWire.decodeOcrTarget(readBodyString(session))

        val bitmap = pacedScreenshot()
            ?: return errorJson(
                Response.Status.INTERNAL_ERROR,
                "screenshot_failed",
                "UiAutomation.takeScreenshot returned null",
            )
        val width = bitmap.width
        val height = bitmap.height

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bitmap, /* rotationDegrees = */ 0)

        // ML Kit is callback-based; block this thread until result lands.
        val latch = JCountDownLatch(1)
        var matchedRect: Rect? = null
        var error: Throwable? = null
        recognizer.process(image)
            .addOnSuccessListener { result ->
                try {
                    val lowerTarget = target.lowercase()
                    for (block in result.textBlocks) {
                        for (line in block.lines) {
                            if (line.text.lowercase().contains(lowerTarget)) {
                                matchedRect = line.boundingBox
                                return@addOnSuccessListener
                            }
                        }
                    }
                } finally {
                    latch.countDown()
                }
            }
            .addOnFailureListener { e ->
                error = e
                latch.countDown()
            }
            .addOnCompleteListener {
                // safety: ensure latch released even on exception in success
                if (latch.count > 0) latch.countDown()
            }
        latch.await(5, TimeUnit.SECONDS)
        bitmap.recycle()

        error?.let {
            return errorJson(
                Response.Status.INTERNAL_ERROR,
                "ocr_failed",
                "ML Kit text recognition: ${it.message}",
            )
        }

        val rect = matchedRect
        val body = if (rect != null && width > 0 && height > 0) {
            RunnerWire.ocrFoundBody(rect.left, rect.top, rect.right, rect.bottom, width, height)
        } else {
            RunnerWire.ocrNotFoundBody()
        }
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveSystemPopups(session: IHTTPSession): Response {
        // Walk UiAutomation.windows and classify each as
        // A popup is a window belonging to somebody other than the app
        // under test with something in it to press. `?app=<pkg>` names
        // the app; without it the focused application window stands in,
        // which is the only thing this route can read when nobody said.
        val automation = instrumentation.uiAutomation
        val app = appUnderTest(session)
        val popupsArr = JSONArray()
        var idx = 0
        for (window in automation.windows) {
            val root = window.root ?: continue
            try {
                if (!WindowRules.isForeignPopup(
                        window.type,
                        root.packageName?.toString(),
                        PopupClassifier.hasPressable(root),
                        window.isActive || window.isFocused,
                        app,
                    )
                ) {
                    continue
                }
                val title = PopupClassifier.findTitle(root)
                val body = PopupClassifier.findBody(root, title)
                val buttons = PopupClassifier.collectButtons(root)
                val popupId = "android-popup-$idx"
                idx += 1
                popupsArr.put(
                    PopupWire.popupEntry(
                        popupId,
                        root.packageName?.toString() ?: "",
                        title,
                        body,
                        buttons,
                    ),
                )
            } finally {
                root.recycle()
            }
        }
        val body = RunnerWire.popupsBody(popupsArr)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveSystemPopupAction(session: IHTTPSession): Response {
        // OK MEANS: action-performed — the button's ACTION_CLICK
        // reported that it ran. The popup going away is the caller's
        // next look.
        val (popupId, buttonId) = RunnerWire.decodeSystemPopupAction(readBodyString(session))
        // The same predicate the listing used, or the ids would count a
        // different set of windows than the one the caller read from.
        val actionApp = appUnderTest(session)
        // Re-walk to find the popup + button (mirror swift smix-runner
        // re-resolve semantics — stale ids surface as ok:false).
        val automation = instrumentation.uiAutomation
        var idx = 0
        var clicked = false
        for (window in automation.windows) {
            val root = window.root ?: continue
            try {
                if (!WindowRules.isForeignPopup(
                        window.type,
                        root.packageName?.toString(),
                        PopupClassifier.hasPressable(root),
                        window.isActive || window.isFocused,
                        actionApp,
                    )
                ) {
                    continue
                }
                val currentId = "android-popup-$idx"
                idx += 1
                if (currentId != popupId) continue
                // Find button matching button_id (we use Compose testTag /
                // viewIdResourceName as button_id).
                val target = PopupClassifier.findButton(root, buttonId) ?: continue
                try {
                    val rect = Rect()
                    target.getBoundsInScreen(rect)
                    if (rect.width() > 0 && rect.height() > 0) {
                        device.click(rect.centerX(), rect.centerY())
                        device.waitForIdle(500)
                        clicked = true
                    }
                } finally {
                    target.recycle()
                }
                break
            } finally {
                root.recycle()
            }
        }
        val body = RunnerWire.popupActionBody(clicked, popupId, buttonId)
        return newFixedLengthResponse(Response.Status.OK, "application/json", body)
    }

    private fun serveWebViewEvalProxy(session: IHTTPSession): Response {
        // OK MEANS: reading — the script's own result is the answer;
        // this route only carries it across the proxy.
        // Runner and app under test live in separate processes; the
        // runner can't access the app's WebView instance directly. Proxy
        // HTTP to the app's shim server on port 28081 (started by
        // MainActivity onCreate via WebViewEvalServer).
        val files = HashMap<String, String>()
        session.parseBody(files)
        val payload = files["postData"] ?: "{}"
        return try {
            val url = java.net.URL("http://127.0.0.1:28081/webview-eval")
            val conn = url.openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 5_000
            conn.readTimeout = 6_000
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val statusEnum = when (status) {
                200 -> Response.Status.OK
                400 -> Response.Status.BAD_REQUEST
                500 -> Response.Status.INTERNAL_ERROR
                else -> Response.Status.lookup(status) ?: Response.Status.INTERNAL_ERROR
            }
            newFixedLengthResponse(statusEnum, "application/json", body)
        } catch (e: Throwable) {
            val body = RunnerWire.proxyFailedBody(e.message ?: e.javaClass.simpleName)
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "application/json", body)
        }
    }

    // The body was already consumed at the top of `serve` — NanoHTTPD
    // can only parse it once, and it MUST be consumed there so the next
    // request on this keep-alive connection is not prefixed with it.
    private fun readBodyString(session: IHTTPSession): String {
        val body = drainedBody.get()
        if (!body.isNullOrEmpty()) return body
        return session.queryParameterString ?: "{}"
    }

    private fun errorJson(status: Response.Status, kind: String, message: String): Response {
        val body = RunnerWire.errorBody(kind, message)
        return newFixedLengthResponse(status, "application/json", body)
    }

    private fun serveNotImplemented(uri: String, method: String): Response {
        val body = RunnerWire.notImplementedBody(uri, method)
        return newFixedLengthResponse(
            Response.Status.NOT_IMPLEMENTED,
            "application/json",
            body,
        )
    }
}

/// Classify a window as dialog-like + walk title/body/buttons. Compose
/// AlertDialog hosts in a separate window with `isDialog=true` OR
/// `type=APPLICATION_PANEL` on API 24+. Fallback heuristic: small window
/// bounds (not full-screen) + has button-like children.
object PopupClassifier {
    /// The name of a thing a caller could press, or null.
    ///
    /// One rule, used by all three things that ask about buttons: is
    /// this window a popup, what is on it, and which node does an id
    /// refer to. They used to ask differently — the listing matched any
    /// class or resource id containing the word "button", the action
    /// route matched class names only — and the navigation bar has a
    /// container called `nav_buttons`. Measured on emulator-5554
    /// 2026-09-23: with the keyboard up, the listing offered the
    /// navigation bar as a popup carrying one nameless button.
    ///
    /// So the question is asked of the node rather than of its
    /// spelling: does it take a click, and can it be named. A button
    /// nobody can name cannot be asked for by a caller either.
    fun pressLabel(node: AccessibilityNodeInfo): String? {
        if (!node.isClickable) return null
        val own = node.text?.toString().orEmpty()
        if (own.isNotEmpty()) return own
        val described = node.contentDescription?.toString().orEmpty()
        if (described.isNotEmpty()) return described
        // Compose wraps the clickable in a parent whose sibling holds
        // the visible label.
        return findSiblingText(node)?.takeIf { it.isNotEmpty() }
    }

    /// Is there anything in this window a caller could press?
    ///
    /// The other half of the popup decision, which lives in
    /// `WindowRules` on the unit-testable side. This half has to walk
    /// `AccessibilityNodeInfo`, so it stays here.
    fun hasPressable(node: AccessibilityNodeInfo): Boolean {
        if (pressLabel(node) != null) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (hasPressable(child)) return true
            } finally {
                child.recycle()
            }
        }
        return false
    }

    /// Find title — first TextView/Text child within dialog that's NOT a
    /// button label.
    fun findTitle(root: AccessibilityNodeInfo): String? {
        return findFirstNonButtonText(root)
    }

    /// Find body — second TextView (after title), skipping button labels.
    fun findBody(root: AccessibilityNodeInfo, title: String?): String? {
        return findFirstNonButtonText(root, skipText = title)
    }

    private fun findFirstNonButtonText(
        node: AccessibilityNodeInfo,
        skipText: String? = null,
        seen: MutableSet<String> = mutableSetOf(),
    ): String? {
        val cls = node.className?.toString() ?: ""
        val text = node.text?.toString()
        if (text != null && text.isNotEmpty() && !cls.endsWith("Button")) {
            if (text != skipText && !seen.contains(text)) {
                seen.add(text)
                return text
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                val found = findFirstNonButtonText(child, skipText, seen)
                if (found != null) return found
            } finally {
                child.recycle()
            }
        }
        return null
    }

    /// Walk all button-class descendants + return JSONArray of {id, label,
    /// role, destructive}.
    fun collectButtons(root: AccessibilityNodeInfo): JSONArray {
        val arr = JSONArray()
        collectButtonsRecursive(root, arr)
        return arr
    }

    private fun collectButtonsRecursive(node: AccessibilityNodeInfo, arr: JSONArray) {
        val label = pressLabel(node)
        if (label != null) {
            val viewId = node.viewIdResourceName ?: ""
            val short = viewId.substringAfter(":id/", viewId)
            val id = PopupWire.buttonId(short, label)
            val role = PopupWire.buttonRole(id, label)
            arr.put(PopupWire.buttonEntry(id, label, role))
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collectButtonsRecursive(child, arr)
            } finally {
                child.recycle()
            }
        }
    }

    /// Compose pattern: TextButton renders as a ViewGroup containing a
    /// TextView (label) + a Button-class node (interactable). Get parent
    /// + look at siblings for a TextView with text.
    private fun findSiblingText(buttonNode: AccessibilityNodeInfo): String? {
        val parent = buttonNode.parent ?: return null
        try {
            for (i in 0 until parent.childCount) {
                val sibling = parent.getChild(i) ?: continue
                try {
                    val sCls = sibling.className?.toString() ?: ""
                    val sText = sibling.text?.toString()
                    if (sText != null && sText.isNotEmpty() && !sCls.endsWith("Button")) {
                        return sText
                    }
                } finally {
                    sibling.recycle()
                }
            }
        } finally {
            parent.recycle()
        }
        return null
    }

    /// Find button by id (testTag-derived OR label-lowercase fallback).
    /// Caller must recycle().
    fun findButton(root: AccessibilityNodeInfo, buttonId: String): AccessibilityNodeInfo? {
        // The id the listing would have given this node, computed the
        // same way. When these two disagreed, a caller could read an id
        // out of `/system-popups` and get `ok:false` pressing it.
        val label = pressLabel(root)
        if (label != null) {
            val viewId = root.viewIdResourceName ?: ""
            val short = viewId.substringAfter(":id/", viewId)
            if (PopupWire.buttonId(short, label).equals(buttonId, ignoreCase = true)) {
                return AccessibilityNodeInfo.obtain(root)
            }
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found: AccessibilityNodeInfo? = try {
                findButton(child, buttonId)
            } finally {
                child.recycle()
            }
            if (found != null) return found
        }
        return null
    }
}

/// Build A11yNode JSON tree from UiAutomation windows. Walks every
/// attached window's AccessibilityNodeInfo tree and merges under a
/// virtual root so the host driver sees foreground app + system windows
/// in a single dump.
object TreeBuilder {
    fun fromWindows(
        automation: UiAutomation,
        display: Pair<Int, Int>,
        hollow: String? = null,
        appWindowIds: Set<Int> = emptySet(),
    ): JSONObject {
        val rootChildren = JSONArray()
        var unreadable = 0
        // Emptied once here, every node below is fetched fresh, its
        // subtree prefetched in the same call; refreshing each one again
        // was a call per node, and on an emulator whose guest CPUs were
        // held by busy loops a tree of the system windows took 240-490 ms
        // that way. Before API 34 there is no cache to empty.
        val fresh = Build.VERSION.SDK_INT >= 34 && automation.clearCache()
        for (window in automation.windows) {
            if (hollow != null && TreeWire.hollowById(window.type, window.id, appWindowIds)) {
                rootChildren.put(hollowWindow(window, hollow))
                continue
            }
            // A window whose root cannot be read is counted, not
            // dropped in silence: absent from the tree and "that app
            // has no accessibility nodes" look identical to the caller,
            // and one of them is smix's problem.
            val node = window.root
            if (node == null) {
                unreadable += 1
                continue
            }
            try {
                val pkg = node.packageName?.toString()
                val obj = nodeToJson(node, walk = !TreeWire.leavesHollow(window.type, pkg, hollow), refresh = !fresh)
                if (obj == null) {
                    unreadable += 1
                    continue
                }
                // A window's own type decides one role that no node class
                // can: the input-method window is the software keyboard.
                // Without this the tree had no keyboard in it at all,
                // while `keyboardIsUp()` two hundred lines up has been
                // reading the very same window type for releases — the
                // capability was in the driver and not in the tree, which
                // is the one place every verb can reach it from.
                TreeWire.roleForWindowType(window.type)?.let { obj.put("role", it) }
                obj.put(
                    "window",
                    TreeWire.windowJson(window.type, pkg, window.isFocused, window.layer, touchableOf(window)),
                )
                rootChildren.put(obj)
            } finally {
                node.recycle()
            }
        }
        return TreeWire.windowRootJson(display.first, display.second, rootChildren, unreadable)
    }

    /// The hollow app's window, from the window alone: where it is, its
    /// layer, its focus and where it takes touches — what the host places
    /// the probe's tree by. Its root is not read.
    private fun hollowWindow(
        window: android.view.accessibility.AccessibilityWindowInfo,
        pkg: String,
    ): JSONObject {
        val b = Rect()
        window.getBoundsInScreen(b)
        return TreeWire.nodeJson(
            rawType = "android.view.Window",
            identifier = null,
            label = null,
            text = null,
            placeholder = null,
            x = b.left,
            y = b.top,
            w = b.width(),
            h = b.height(),
            enabled = true,
            selected = false,
            hasFocus = window.isFocused,
            visible = true,
            children = JSONArray(),
        ).put("window", TreeWire.windowJson(window.type, pkg, window.isFocused, window.layer, touchableOf(window)))
    }

    /// Where `window` takes touches, each rectangle as `[left, top, width, height]`.
    private fun touchableOf(window: android.view.accessibility.AccessibilityWindowInfo): List<IntArray> =
        HitReader.touchRects(window).map { intArrayOf(it.left, it.top, it.right - it.left, it.bottom - it.top) }

    /// `null` when the node no longer exists: its subtree is left out.
    private fun nodeToJson(node: AccessibilityNodeInfo, walk: Boolean = true, refresh: Boolean = true): JSONObject? {
        // Per-node refresh parity with the /tap-by-id walkFind path.
        // Chained NavHost transitions leave cached AccessibilityNodeInfo
        // descendants stale even after parent root.refresh(); a tree
        // dump without per-node refresh reports the pre-transition
        // state while screencap shows the next screen actually
        // rendered. Refreshing per-node forces the framework to re-sync
        // each child with current Compose semantics.
        //
        // `refresh` answers false when the view behind the node is gone,
        // and leaves the node holding what it last knew — reporting it
        // would put something on the screen that is not.
        if (refresh && !node.refresh()) return null
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val childArr = JSONArray()
        for (i in 0 until if (walk) node.childCount else 0) {
            val child = node.getChild(i) ?: continue
            try {
                nodeToJson(child, refresh = refresh)?.let { childArr.put(it) }
            } finally {
                child.recycle()
            }
        }
        return TreeWire.nodeJson(
            rawType = node.className?.toString() ?: "",
            identifier = node.viewIdResourceName,
            label = node.contentDescription?.toString(),
            text = FieldText.held(node.text, node.isShowingHintText),
            placeholder = node.hintText?.toString(),
            x = rect.left,
            y = rect.top,
            w = rect.right - rect.left,
            h = rect.bottom - rect.top,
            enabled = node.isEnabled,
            selected = node.isSelected,
            hasFocus = node.isFocused,
            visible = node.isVisibleToUser || (rect.width() > 0 && rect.height() > 0),
            children = childArr,
        )
    }
}

/// Parse UiAutomator2 dumpWindowHierarchy XML → smix A11yNode JSON.
///
/// Mapping (Android XML attribute → A11yNode JSON field):
/// - class                → rawType
/// - (derived from class) → role (Button/TextField/Image/Switch/CheckBox/StaticText etc.)
/// - resource-id          → identifier (last segment after ":id/" if prefixed)
/// - content-desc         → label
/// - text                 → text
/// - bounds="[x1,y1][x2,y2]" → bounds: {x: x1, y: y1, w: x2-x1, h: y2-y1}
/// - enabled              → enabled
/// - selected             → selected
/// - focused              → hasFocus
/// - visible-to-user      → visible (else derived from bounds non-empty)
/// - children             → children (recursive)
object TreeXmlParser {
    private val BOUNDS_RX = Regex("""\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]""")

    fun parse(xml: ByteArray): JSONObject {
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        val parser = factory.newPullParser()
        parser.setInput(ByteArrayInputStream(xml), "UTF-8")

        var event = parser.eventType
        val stack = ArrayDeque<JSONObject>()
        var root: JSONObject? = null

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "hierarchy") {
                        // Root <hierarchy rotation="N"> wraps the top-level node.
                        // Skip; the next <node ...> is the real root.
                    } else if (parser.name == "node") {
                        val obj = JSONObject()
                        val cls = parser.getAttributeValue(null, "class") ?: ""
                        obj.put("rawType", cls)
                        TreeWire.deriveRole(cls)?.let { obj.put("role", it) }

                        parser.getAttributeValue(null, "resource-id")
                            ?.takeIf { it.isNotEmpty() }
                            ?.let { obj.put("identifier", TreeWire.shortResourceId(it)) }
                        parser.getAttributeValue(null, "content-desc")
                            ?.takeIf { it.isNotEmpty() }
                            ?.let { obj.put("label", it) }
                        parser.getAttributeValue(null, "text")
                            ?.takeIf { it.isNotEmpty() }
                            ?.let { obj.put("text", it) }

                        val boundsStr = parser.getAttributeValue(null, "bounds") ?: ""
                        obj.put("bounds", parseBounds(boundsStr))

                        obj.put("enabled", parser.getAttributeValue(null, "enabled") == "true")
                        obj.put("selected", parser.getAttributeValue(null, "selected") == "true")
                        obj.put("hasFocus", parser.getAttributeValue(null, "focused") == "true")

                        // visible: prefer visible-to-user when present, else
                        // derive from bounds (non-zero w/h).
                        val visibleAttr = parser.getAttributeValue(null, "visible-to-user")
                        val visible = when {
                            visibleAttr == "true" -> true
                            visibleAttr == "false" -> false
                            else -> {
                                val b = obj.getJSONObject("bounds")
                                b.optDouble("w", 0.0) > 0 && b.optDouble("h", 0.0) > 0
                            }
                        }
                        obj.put("visible", visible)

                        obj.put("children", JSONArray())

                        if (stack.isEmpty()) {
                            root = obj
                        } else {
                            stack.last().getJSONArray("children").put(obj)
                        }
                        stack.addLast(obj)
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "node") {
                        stack.removeLast()
                    }
                }
            }
            event = parser.next()
        }
        // If no <node> seen (empty hierarchy / weird state), emit a minimal
        // placeholder root so /tree always returns a valid A11yNode shape.
        return root ?: JSONObject()
            .put("rawType", "android.view.View")
            .put("bounds", JSONObject().put("x", 0).put("y", 0).put("w", 0).put("h", 0))
            .put("enabled", false)
            .put("selected", false)
            .put("hasFocus", false)
            .put("visible", false)
            .put("children", JSONArray())
    }

    private fun parseBounds(s: String): JSONObject {
        val m = BOUNDS_RX.find(s)
        if (m != null) {
            val (x1, y1, x2, y2) = m.destructured
            val ix1 = x1.toInt(); val iy1 = y1.toInt()
            val ix2 = x2.toInt(); val iy2 = y2.toInt()
            return JSONObject()
                .put("x", ix1)
                .put("y", iy1)
                .put("w", (ix2 - ix1).coerceAtLeast(0))
                .put("h", (iy2 - iy1).coerceAtLeast(0))
        }
        return JSONObject().put("x", 0).put("y", 0).put("w", 0).put("h", 0)
    }
}
